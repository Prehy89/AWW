'use strict';
// Public geometry/navigation helpers only. No indicators or trading rules.
(function(root){
 const lower=(a,x)=>{let l=0,h=a.length;while(l<h){const m=(l+h)>>>1;if(a[m]<x)l=m+1;else h=m;}return l;};
 function position(a,t){const i=lower(a,t);if(!a.length)return 0;if(i===0)return 0;if(i>=a.length)return a.length-1;return i-1+(t-a[i-1])/(a[i]-a[i-1]);}
 function clamp(start,count,n,minimum=5){count=Math.max(Math.min(minimum,n),Math.min(n,count));return {start:Math.max(0,Math.min(n-count,start)),count};}
 function zoom(start,count,n,factor,anchor=.5){const center=start+count*anchor,c=clamp(start,count*factor,n);return clamp(center-c.count*anchor,c.count,n);}
 // Buttons keep the last visible candle. At the oldest boundary, stop expanding
 // instead of moving the right endpoint to a newer date.
 function zoomRight(start,count,n,factor){const end=Math.min(n,Math.max(1,Math.ceil(start+count))),size=Math.min(end,Math.max(Math.min(5,end),Math.round(count*factor)));return {start:end-size,count:size};}
 function windowFor(dates,from,to){const a=lower(dates,from),b=lower(dates,to+'\uffff');return b>a?{start:a,count:b-a}:null;}
 // Calendar bounds include whole years, but only existing observations.
 function calendarYears(dates,from,to){if(!/^\d{4}$/.test(String(from))||!/^\d{4}$/.test(String(to))||from>to)return null;return windowFor(dates,from+'-01-01',to+'-12-31');}
 function sinceYear(dates,year){if(!dates.length||!dates.some(d=>d.startsWith(String(year))))return null;return calendarYears(dates,year,dates.at(-1).slice(0,4));}
 const api={lower,position,clamp,zoom,zoomRight,windowFor,sinceYear,calendarYears};if(typeof module!=='undefined')module.exports=api;else root.AWW_VIEW_NAV=Object.freeze(api);
})(typeof window==='undefined'?{}:window);
