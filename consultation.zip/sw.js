'use strict';
const prefix='aww-consultation-'+self.registration.scope+'-',cacheName=prefix+'483a718a2dafb62b2d750698e96f038bc1ea5ba8c8469346ee33a970b1e293e7';
const shell=['./','index.html','viewer.js','viewer.css','navigation.js','catalog.json','manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(cacheName).then(c=>c.addAll(shell)).then(()=>self.skipWaiting())));
// Same-address migration: remove only the former AWW shell cache for this exact
// scope, once the new consultation shell has installed successfully.
const legacyPrefix='aww:'+self.registration.scope+':';
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(prefix)&&k!==cacheName||k.startsWith(legacyPrefix)).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;const url=new URL(event.request.url),base=new URL(self.registration.scope);
 if(url.origin!==base.origin||!url.pathname.startsWith(base.pathname))return;
 const rel=url.pathname.slice(base.pathname.length);if(!shell.includes(rel||'./')&&!/^data\/[a-f0-9]{64}\.json$/.test(rel))return;
 event.respondWith((async()=>{const c=await caches.open(cacheName);if(rel.startsWith('data/')){const hit=await c.match(event.request);if(hit)return hit;}
  try{const response=await fetch(event.request);if(response.ok)await c.put(event.request,response.clone());return response;}catch(e){const cached=await c.match(event.request);if(cached)return cached;throw e;}
 })());
});
