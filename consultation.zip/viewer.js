'use strict';
/** Public display-only reader. Its inputs are already-computed curves, labels
 * and drawing geometry. No calls to a financial engine or external data API. */
(()=>{
const $=id=>document.getElementById(id),N=AWW_VIEW_NAV,F=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}),compact=()=>innerWidth<=760;
const fmt=x=>Number.isFinite(x)?F.format(x):'—',date=s=>s?s.slice(8,10)+'/'+s.slice(5,7)+'/'+s.slice(0,4)+(s.length>10?' '+s.slice(11,16)+' UTC':''):'—';
const state={catalog:null,view:null,dates:[],times:[],panels:[],start:0,count:80,hover:null,raf:0,request:0,log:false};
const cache=new Map(),pointers=new Map();let gesture=null,observer=null;
async function json(url){const r=await fetch(url,{cache:url==='catalog.json'?'no-cache':'default'});if(!r.ok)throw Error('Fichier indisponible ('+r.status+') : '+url);const raw=await r.text();
 if(url.startsWith('data/')){const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw));const hex=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');if(url!=='data/'+hex+'.json')throw Error('Données incomplètes : rechargez la page.');}
 return JSON.parse(raw);
}
async function chunk(url){if(!/^data\/[a-f0-9]{64}\.json$/.test(url))throw Error('Chemin de données invalide');if(!cache.has(url)){if(cache.size>45)cache.clear();cache.set(url,json(url).catch(e=>{cache.delete(url);throw e;}));}return cache.get(url);}
function scenarios(){const h4=$('unit').value==='h4',old=$('scenario').value,items=h4?[['LONG_ONLY','Long uniquement'],['SHORT_ONLY','Short uniquement'],['BOTH','Long + short']]:[['classic','BAM standard'],['bam-flat','Premier BAM short → flat']];$('scenario').replaceChildren(...items.map(([value,text])=>new Option(text,value)));if(items.some(x=>x[0]===old))$('scenario').value=old;}
function setStatus(text){$('status').textContent=text;}
async function loadView(initial=false){
 const request=++state.request,oldFrom=state.dates[Math.floor(state.start)]?.slice(0,10),oldTo=state.dates[Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1)]?.slice(0,10);
 const v=state.catalog.views.find(v=>v.index===$('index').value&&v.tf===$('unit').value&&v.scenario===$('scenario').value);if(!v)return;
 setStatus('Chargement des résultats précalculés…');$('charts').classList.add('loading');
 try{
  const [dates,...panels]=await Promise.all([chunk(v.calendar),...v.panels.map(chunk)]);if(request!==state.request)return;
  state.view=v;state.dates=dates;state.times=dates.map(Date.parse);state.panels=panels.map(p=>({...p,series:p.series.map(s=>({...s,points:s.points.filter(r=>r[0]>=dates[0].slice(0,10)&&r[0]<=dates.at(-1)+'\uffff').map(([d,v])=>({date:d,v,i:N.position(state.times,Date.parse(d))}))})),candles:p.candles?.map(r=>({date:r[0],open:r[1],high:r[2],low:r[3],close:r[4],provisional:r[5],boost:r[6],i:N.position(state.times,Date.parse(r[0]))})),visible:true}));
  for(const m of state.panels){for(const s of m.series){s.indices=s.points.map(p=>p.i);s.dates=s.points.map(p=>p.date);}m.candleDates=m.candles?.map(r=>r.date);m.dcaDates=m.dca?.map(r=>r[0]);m.drawdownDates=m.drawdownSeries?.map(r=>r[0]);}
  state.hover=null;gesture=null;pointers.clear();
  let range=!initial&&oldFrom?N.windowFor(dates,oldFrom,oldTo):null;if(!range)range=compact()?{start:Math.max(0,dates.length-80),count:Math.min(80,dates.length)}:N.windowFor(dates,(+v.to.slice(0,4)-3)+v.to.slice(4,10),v.to.slice(0,10));
  Object.assign(state,N.clamp(range?.start||0,range?.count||dates.length,dates.length));
  $('coverage').textContent=date(v.from)+' → '+date(v.to)+' · '+fmt(v.bars)+' bougies · export du '+date(state.catalog.generatedAt);
  for(const id of ['from','to']){$(id).min=v.from.slice(0,10);$(id).max=v.to.slice(0,10);}
  createPanels();sync();setStatus('');
 }catch(e){if(request===state.request)setStatus('Impossible de charger cette vue. '+e.message);}
 finally{if(request===state.request)$('charts').classList.remove('loading');}
}
function textNode(tag,text,cls){const e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;return e;}
function createPanels(){
 observer?.disconnect();$('charts').replaceChildren();
 for(const m of state.panels){
  const article=document.createElement('article');article.className='panel '+(m.kind==='price'?'price':m.id);article.append(textNode('h2',m.title));
  const metrics=textNode('div','','metrics');m.metrics=metrics;article.append(metrics);
  const plot=textNode('div','','chart'),canvas=document.createElement('canvas');canvas.tabIndex=0;canvas.setAttribute('role','img');canvas.setAttribute('aria-label',m.title+' : flèches pour parcourir, + et − pour zoomer');canvas.dataset.panel=m.id;plot.append(canvas);article.append(plot);m.canvas=canvas;
  if(m.kind==='price'){const nav=textNode('div','','navigator');nav.append(textNode('span','Parcourir'));const input=document.createElement('input');input.type='range';input.id='navigator';input.setAttribute('aria-label','Parcourir l’historique');input.min=0;input.step=.1;input.oninput=()=>{state.start=+input.value;state.hover=null;sync();};nav.append(input);article.append(nav);}
  const details=document.createElement('details');details.append(textNode('summary','Info'));details.open=!compact();
  const info=textNode('div','','info');
  const legend=textNode('div','','legend');for(const s of m.series){const el=textNode('span',s.label);const swatch=document.createElement('i');swatch.style.background=s.color;el.prepend(swatch);legend.append(el);}info.append(legend);
  // Axis conventions are explained by the reader itself, avoiding stale hints
  // tied to the private dashboard's layout.
  info.append(textNode('p',m.id==='ad'?'AD quotidienne à gauche ; Dow quotidien à droite.':m.id==='hl'?'Solde NH−NL hebdomadaire à droite ; Dow hebdomadaire à gauche.':m.id==='position'&&state.view.tf==='h4'?'Position à la clôture de chaque bougie : +100 % long, −100 % short, 0 % flat. Paramètres précalculés dans la version complète.':m.legend));
  if(m.kind==='price')info.append(textNode('p','Molette / deux doigts : zoom · Glisser : dates · Appui : valeurs. Les signaux affichés sont précalculés.'));
  if(m.dca)info.append(textNode('p','DCA : vert clair M mensuel ; vert foncé H hebdomadaire, même montant par achat. Bleu ×0 : pause ; rouge ×−1 : short et achats suspendus. Jaune : réserve disponible. Voir la notice.'));
  m.readout=textNode('div','','readout');info.append(m.readout);details.append(info);article.append(details);$('charts').append(article);m.article=article;bind(m);
 }
 if('IntersectionObserver' in window){observer=new IntersectionObserver(entries=>{for(const e of entries){const m=state.panels.find(m=>m.canvas===e.target);if(m)m.visible=e.isIntersecting;}schedule();},{rootMargin:'250px'});state.panels.forEach(m=>observer.observe(m.canvas));}
}
function sync(){Object.assign(state,N.clamp(state.start,state.count,state.dates.length));$('from').value=state.dates[Math.floor(state.start)]?.slice(0,10)||'';$('to').value=state.dates[Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1)]?.slice(0,10)||'';const slider=$('navigator');if(slider){slider.max=Math.max(0,state.dates.length-state.count);slider.value=state.start;}schedule();}
function schedule(){if(!state.raf)state.raf=requestAnimationFrame(()=>{state.raf=0;for(const m of state.panels){if(m.visible)paint(m);updateReadout(m);}});}
function zoom(f,anchor=.5){Object.assign(state,N.zoom(state.start,state.count,state.dates.length,f,anchor));state.hover=null;sync();}
function years(value){const v=state.view;if(!v)return;const range=value==='all'?{start:0,count:state.dates.length}:N.windowFor(state.dates,(+v.to.slice(0,4)-Number(value))+v.to.slice(4,10),v.to.slice(0,10));if(range){Object.assign(state,range);state.hover=null;sync();}}
const pos=d=>N.position(state.times,Date.parse(d));
function visibleZones(zones,end){const groups=new Map();for(const z of zones||[])if(z.knownAt<=end){const old=groups.get(z.group);if(!old||old.knownAt<=z.knownAt)groups.set(z.group,z);}return [...groups.values()];}
function getSlice(series){const a=Math.max(0,N.lower(series.indices,state.start)-1),b=N.lower(series.indices,state.start+state.count)+1;return series.points.slice(a,b);}
function scale(values,log,zero){let lo=Infinity,hi=-Infinity;for(const v of values)if(Number.isFinite(v)&&(!log||v>0)){lo=Math.min(lo,v);hi=Math.max(hi,v);}if(lo===Infinity){lo=0;hi=1;log=false;}if(zero&&!log){lo=Math.min(0,lo);hi=Math.max(0,hi);}if(log){lo=Math.log(lo);hi=Math.log(hi);}const margin=(hi-lo)*.10||Math.abs(hi)*.05||1;return {lo:lo-margin,hi:hi+margin,log};}
/** Place a symbol + caption outside nearby candle wicks. This is screen-space
 * layout only: dates, execution prices and financial results never change.
 * Crowded zoomed-out views keep symbols; captions reappear as space permits. */
function markerLayout(items,candles,bounds,measure,showText){
 const placed=[],overlaps=(a,b)=>a.left<b.right+3&&a.right>b.left-3&&a.top<b.bottom+3&&a.bottom>b.top-3;
 const priority=m=>m.peer?2:m.shape==='mm200'?3:m.shape==='bam'||m.shape==='bam-reference'?1:0;
 for(const item of [...items].sort((a,b)=>priority(a.mark)-priority(b.mark)||a.x-b.x)){
  const mark=item.mark,above=mark.side==='SELL'||mark.side==='FLAT'||mark.shape==='exit'||mark.shape==='mm200';
  let candidate=null;
  for(const caption of showText?[true,false]:[false]){
   const width=caption?Math.max(14,measure(mark.label)+10):12,height=caption?30:12;
   const center=Math.max(bounds.left+width/2+2,Math.min(bounds.right-width/2-2,item.x));
   const near=candles.filter(r=>r.right>=center-width/2-3&&r.left<=center+width/2+3);
   const high=Math.min(item.y,...near.map(r=>r.top)),low=Math.max(item.y,...near.map(r=>r.bottom));
   for(const sign of [above?-1:1,above?1:-1]){
    for(let lane=0;lane<6;lane++){
     const tip=(sign<0?high-12:low+12)+sign*lane*(height+4);
     const box={left:center-width/2,right:center+width/2,top:sign<0?tip-height:tip,bottom:sign<0?tip:tip+height};
     if(box.top<bounds.top+2||box.bottom>bounds.bottom-2)continue;
     if(placed.some(p=>overlaps(box,p.box))||near.some(r=>overlaps(box,r)))continue;
     candidate={...item,center,tip,sign,caption,box};break;
    }if(candidate)break;
   }if(candidate)break;
  }
  if(candidate)placed.push(candidate);
 }
 return placed;
}
function paint(m){
 const canvas=m.canvas,w=canvas.clientWidth,h=canvas.clientHeight;if(!w||!h)return;const ratio=Math.min(devicePixelRatio||1,3);if(canvas.width!==Math.round(w*ratio)||canvas.height!==Math.round(h*ratio)){canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);}const c=canvas.getContext('2d');c.setTransform(ratio,0,0,ratio,0,0);c.clearRect(0,0,w,h);
 const small=w<600,left=small?44:68,right=w-(small?61:79),top=16,bottom=h-(m.dca?82:30),width=right-left,height=bottom-top;if(width<10||height<10)return;
 const x=i=>left+(i-state.start+.5)/state.count*width,at=i=>state.dates[Math.max(0,Math.min(state.dates.length-1,Math.floor(i)))],end=at(state.start+state.count-1),hasLast=state.start+state.count>=state.dates.length-.1;
 const candles=(m.candles||[]).filter(r=>r.i>=state.start-1&&r.i<=state.start+state.count),all=m.series.map(s=>({...s,visible:getSlice(s)}));
 const primary=scale([...all.filter(s=>s.axis!=='secondary'&&!(m.kind==='price'&&s.key==='close')).flatMap(s=>s.visible.map(p=>p.v)),...candles.flatMap(r=>[r.low,r.high]),...(m.kind!=='price'?all.filter(s=>s.axis!=='secondary').flatMap(s=>s.visible.map(p=>p.v)):[])],m.kind==='price'?$('log').checked:m.log,m.zero);
 if(m.kind==='price'&&$('annotations').checked){const space=(primary.hi-primary.lo)*.055;primary.lo-=space;primary.hi+=space;}
 if(m.kind==='price'&&m.yZoom){const mid=(primary.hi+primary.lo)/2,half=(primary.hi-primary.lo)*m.yZoom/2;primary.lo=mid-half;primary.hi=mid+half;}
 const secondary=scale(all.filter(s=>s.axis==='secondary').flatMap(s=>s.visible.map(p=>p.v)),false,false),yOf=(v,s)=>top+(s.hi-(s.log?Math.log(v):v))/(s.hi-s.lo)*height,y=v=>yOf(v,primary),sy=v=>yOf(v,secondary);
 m.geom={left,right,top,bottom,width,x};c.font=(small?'700 10px':'600 11px')+' Segoe UI, Arial';c.lineWidth=1;
 const hasSecondary=all.some(s=>s.axis==='secondary'),primaryLeft=hasSecondary&&m.id==='ad';
 function axis(s,isLeft){c.textAlign=isLeft?'right':'left';for(let j=0;j<=4;j++){const yy=top+height*j/4,v=s.hi-(s.hi-s.lo)*j/4;c.fillStyle='#59718a';c.fillText(fmt(s.log?Math.exp(v):v),isLeft?left-6:right+6,yy+4);}}
 for(let j=0;j<=4;j++){const yy=top+height*j/4;c.strokeStyle='#e7eef5';c.beginPath();c.moveTo(left,yy);c.lineTo(right,yy);c.stroke();}axis(primary,primaryLeft);if(hasSecondary)axis(secondary,!primaryLeft);
 c.textAlign='center';const ticks=Math.max(2,Math.floor(width/(small?90:120))),seen=new Set();for(let j=0;j<=ticks;j++){const i=Math.min(state.dates.length-1,Math.floor(state.start+(state.count-1)*j/ticks)),d=at(i);const label=state.view.tf==='weekly'?d.slice(0,4):d.slice(8,10)+'/'+d.slice(5,7)+(state.count>200?'/'+d.slice(2,4):'');if(!seen.has(label)){c.fillStyle='#59718a';c.fillText(label,Math.max(left+20,Math.min(right-23,x(i))),h-8);seen.add(label);}}
 c.save();c.beginPath();c.rect(left,top,width,height);c.clip();
 if(m.kind==='price'){let year=null;for(let i=Math.floor(state.start);i<Math.min(state.dates.length,state.start+state.count);i++){const yr=state.dates[i].slice(0,4);if(year!==null&&yr!==year){c.strokeStyle='#91a7bc';c.beginPath();c.moveTo(x(i)-width/state.count/2,top);c.lineTo(x(i)-width/state.count/2,bottom);c.stroke();}year=yr;}}
 if($('annotations').checked)for(const z of visibleZones(m.zones,end)){const a=x(pos(z.from)),b=x(pos(z.to));if(b<left||a>right)continue;c.fillStyle=z.shade;c.fillRect(a,top,b-a,height);if(Number.isFinite(z.a)&&Number.isFinite(z.b)){c.strokeStyle=z.color;c.setLineDash([]);c.beginPath();c.moveTo(a,y(z.a));c.lineTo(b,y(z.b));c.stroke();}if(hasSecondary&&Number.isFinite(z.priceA)&&Number.isFinite(z.priceB)){c.strokeStyle=z.color;c.setLineDash([4,3]);c.beginPath();c.moveTo(a,sy(z.priceA));c.lineTo(b,sy(z.priceB));c.stroke();}c.setLineDash([]);}
 if(m.zero){c.strokeStyle='#7495ba';c.setLineDash([3,3]);c.beginPath();c.moveTo(left,y(0));c.lineTo(right,y(0));c.stroke();c.setLineDash([]);}
 for(const s of all){if(m.kind==='price'&&s.key==='close'&&$('style').value==='candles')continue;if((s.key==='ma'||s.key==='ma30')&&!$('averages').checked)continue;const yy=s.axis==='secondary'?sy:y;
  c.strokeStyle=s.color;c.fillStyle=s.color;c.lineWidth=s.width||1.35;c.setLineDash(s.dash?[4,3]:[]);c.beginPath();let prev=null;
  for(let j=0;j<s.visible.length;j++){const p=s.visible[j];if(!Number.isFinite(p.v)||primary.log&&s.axis!=='secondary'&&p.v<=0){prev=null;continue;}const xx=x(p.i),py=yy(p.v);
   if(s.bar){const neighbor=s.visible[j+1]||s.visible[j-1],spacing=neighbor?Math.abs(x(neighbor.i)-xx):width/state.count,bw=Math.min(24,Math.max(1.5,spacing*.78));c.fillStyle=p.v>=0?s.positiveColor||s.color:s.negativeColor||'#d64564';c.fillRect(xx-bw/2,Math.min(py,yy(0)),bw,Math.max(1,Math.abs(py-yy(0))));}
   else{if(prev&&(!s.gap||Date.parse(p.date)-Date.parse(prev.date)<=s.gap)){if(s.signed){c.stroke();c.beginPath();c.strokeStyle=p.v>=0?'#13846c':'#c14d5b';c.moveTo(x(prev.i),yy(prev.v));}if(s.step)c.lineTo(xx,yy(prev.v));c.lineTo(xx,py);}else c.moveTo(xx,py);prev=p;}
  }if(!s.bar)c.stroke();c.setLineDash([]);
 }
 if(m.kind==='price'&&$('style').value==='candles'){
  const bw=Math.max(.8,Math.min(15,width/state.count*.68));for(const r of candles){const xx=x(r.i),up=r.close>=r.open;c.strokeStyle=r.boost?'#198754':up?'#242a32':'#bc4657';c.fillStyle=up?'white':'#e78694';c.lineWidth=r.boost?2:1;c.setLineDash(r.provisional?[2,2]:[]);c.beginPath();c.moveTo(xx,y(r.high));c.lineTo(xx,y(r.low));c.stroke();const py=Math.min(y(r.open),y(r.close)),ph=Math.max(1,Math.abs(y(r.close)-y(r.open)));c.fillRect(xx-bw/2,py,bw,ph);c.strokeRect(xx-bw/2,py,bw,ph);}c.setLineDash([]);c.lineWidth=1;
 }
 if($('annotations').checked){
  for(const s of m.segments){if(s.knownAt>end||s.to<at(state.start)||s.from>end)continue;const a=pos(s.from),b=pos(s.to),last=Math.min(b,state.start+state.count-.5),value=s.a+(s.b-s.a)*(last-a)/(b-a||1);c.strokeStyle=s.color;c.setLineDash(s.dash?[3,3]:[]);c.beginPath();c.moveTo(x(a),y(s.a));c.lineTo(x(last),y(value));c.stroke();}c.setLineDash([]);
  const candlePixels=candles.map(r=>({left:x(r.i)-Math.max(1,width/state.count*.4),right:x(r.i)+Math.max(1,width/state.count*.4),top:y(r.high),bottom:y(r.low)}));
  const items=m.markers.filter(mark=>mark.knownAt<=end).map(mark=>({mark,i:pos(mark.date),x:x(pos(mark.date)),y:y(mark.value)})).filter(p=>p.i>=state.start&&p.i<state.start+state.count&&Number.isFinite(p.y));
  m.markerLayout=markerLayout(items,candlePixels,{left,right,top,bottom},s=>c.measureText(s).width,state.count<650);
  for(const p of m.markerLayout){const mark=p.mark,xx=p.center,tip=p.tip,sign=p.sign;
   c.strokeStyle=mark.color;c.lineWidth=1;c.setLineDash([2,3]);c.globalAlpha=.55;c.beginPath();c.moveTo(p.x,Math.max(top,Math.min(bottom,p.y)));c.lineTo(xx,tip-sign*3);c.stroke();c.globalAlpha=1;c.setLineDash(mark.provisional?[2,2]:[]);
   c.lineWidth=1.5;c.fillStyle=mark.peer?'white':mark.color;c.beginPath();
   if(mark.shape==='exit'){const cy=tip+sign*5;c.moveTo(xx-4,cy-4);c.lineTo(xx+4,cy+4);c.moveTo(xx-4,cy+4);c.lineTo(xx+4,cy-4);}
   else if(mark.shape==='bam'||mark.shape==='bam-reference'){const cy=tip+sign*5;c.moveTo(xx,cy-5);c.lineTo(xx+5,cy);c.lineTo(xx,cy+5);c.lineTo(xx-5,cy);c.closePath();c.fill();}
   else{const cy=tip+sign*5,down=mark.side==='SELL'||mark.side==='FLAT'||mark.shape==='mm200',direction=down?1:-1;c.moveTo(xx,cy+5*direction);c.lineTo(xx-5,cy-4*direction);c.lineTo(xx+5,cy-4*direction);c.closePath();c.fill();}c.stroke();c.setLineDash([]);
   if(p.caption){const baseline=sign>0?tip+25:tip-17;c.fillStyle='#ffffffdf';c.fillRect(p.box.left,baseline-10,p.box.right-p.box.left,14);c.fillStyle=mark.color;c.textAlign='center';c.fillText(mark.label,xx,baseline);}
  }
  for(const dd of m.drawdowns||[]){if(dd.confirmed>end)continue;const xx=x(pos(dd.date));if(xx<left||xx>right)continue;c.fillStyle=dd.tone==='short'?'#c14d5b':dd.tone==='flat'?'#1675c5':'#c47b21';c.textAlign='center';c.fillText(fmt(dd.percent)+' %',xx,Math.max(top+10,Math.min(bottom-3,y(dd.value)+25)));}
  if(hasLast&&m.risk&&Number.isFinite(m.risk.level)){c.strokeStyle=m.risk.color;c.setLineDash([4,4]);c.beginPath();c.moveTo(Math.max(left,right-170),y(m.risk.level));c.lineTo(right,y(m.risk.level));c.stroke();c.setLineDash([]);}
 }
 c.restore();
 if(m.dca){
  const rails=[['AD cum.',m.ribbons?.ad],['NH−NL',m.ribbons?.hl]];rails.forEach(([label,zs],j)=>{const yy=bottom+9+j*12;c.fillStyle='#eaf0f5';c.fillRect(left,yy,width,7);if($('annotations').checked)for(const z of visibleZones(zs,end)){const a=Math.max(left,x(pos(z.from))),b=Math.min(right,x(pos(z.to)));if(b>a){c.fillStyle=z.color+'88';c.fillRect(a,yy,b-a,7);}}c.fillStyle='#5b7288';c.textAlign='right';c.fillText(label,left-5,yy+7);});
  const yy=bottom+34;c.fillStyle='#5b7288';c.textAlign='right';c.fillText('DCA',left-5,yy+9);let segment=null;const flush=()=>{if(!segment)return;const a=Math.max(left,segment.a),b=Math.min(right,segment.b);if(b<=a)return;c.fillStyle=segment.color;c.fillRect(a,yy,b-a,12);if(b-a>27){c.fillStyle=segment.label==='M'?'#285337':'white';c.textAlign='center';c.fillText(segment.label,(a+b)/2,yy+10);}};
  for(const [d,label,color] of m.dca){const i=pos(d);if(i<state.start-1||i>state.start+state.count)continue;const a=x(i)-width/state.count/2,b=a+width/state.count;if(segment?.label===label)segment.b=b;else{flush();segment={a,b,label,color};}}flush();
  for(const [d] of m.bams||[]){const xx=x(pos(d));if(xx>=left&&xx<=right){c.fillStyle='#f0cc25';c.fillRect(xx-2,yy,4,12);}}
 }
 if(state.hover!==null){const xx=x(state.hover);if(xx>=left&&xx<=right){c.strokeStyle='#567ba0';c.setLineDash([3,3]);c.beginPath();c.moveTo(xx,top);c.lineTo(xx,bottom);c.stroke();c.setLineDash([]);}}
 m.metrics.replaceChildren();if(m.stats){const s=m.stats;m.metrics.append(textNode('span',Number.isFinite(s.cagr)?'CAGR '+fmt(s.cagr)+' %':'Performance '+fmt(s.cumulativeReturnPct)+' %'),textNode('span','DD maximal '+fmt(s.maxDrawdown??s.maxDrawdownPct)+' %'),textNode('span','Historique complet · '+date(s.from)+' — '+date(s.to)));}
 if(hasLast&&m.kind==='price'){
  for(const r of m.readouts||[]){const span=textNode('span',r.text);span.style.color=r.color;m.metrics.append(span);}
  if(m.currentDrawdown)m.metrics.append(textNode('span','DD en cours '+fmt(m.currentDrawdown.percent)+' %'));
  if(m.risk){const span=textNode('span',[m.risk.label,m.risk.missingText].filter(Boolean).join(' · '));span.style.color=m.risk.color;span.title=[m.risk.detail,m.risk.snapshotText,m.risk.description].filter(Boolean).join(' · ');m.metrics.append(span);}
 }
}
function updateReadout(m){const i=state.hover===null?Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1):Math.round(state.hover),d=state.dates[i];if(!d)return;const messages=[date(d)];
 if(m.candles){const rows=m.candles,j=N.lower(m.candleDates,d),r=rows[j]?.date===d?rows[j]:rows[j-1];if(r)messages.push('O '+fmt(r.open)+' · H '+fmt(r.high)+' · B '+fmt(r.low)+' · C '+fmt(r.close)+(r.provisional?' · bougie en cours':''));}
 for(const s of m.series){let j=N.lower(s.dates,d+'\uffff')-1;while(j>=0&&!Number.isFinite(s.points[j].v))j--;const p=s.points[j];if(p)messages.push(s.label+' '+fmt(p.v)+(p.date!==d?' (au '+date(p.date)+')':''));}
 for(const e of m.markers)if(Math.round(pos(e.date))===i&&e.knownAt<=d)messages.push(e.label+' à '+fmt(e.executionValue??e.value));
 if(m.dca){const j=N.lower(m.dcaDates,d+'\uffff')-1,r=m.dca[j];if(r)messages.push('DCA '+r[1]);for(const [day,label] of m.bams||[])if(Math.round(pos(day))===i)messages.push(label);}
 if(m.drawdownSeries){const j=N.lower(m.drawdownDates,d+'\uffff')-1;messages.push('DD équité '+fmt(m.drawdownSeries[j]?.[1])+' %');}
 if(m.risk&&d>=m.risk.asOf)messages.push(m.risk.description);
 m.readout.textContent=messages.join(' · ');
}
function bind(m){const el=m.canvas;
 const xy=e=>{const r=el.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};};
 const fraction=x=>Math.max(0,Math.min(1,(x-m.geom.left)/m.geom.width));
 el.addEventListener('wheel',e=>{if(!m.geom)return;e.preventDefault();zoom(Math.exp(Math.max(-200,Math.min(200,e.deltaY))*.002),fraction(xy(e).x));},{passive:false});
 el.addEventListener('pointerdown',e=>{if(!m.geom||e.button!==0)return;const p=xy(e);pointers.set(e.pointerId,p);el.setPointerCapture(e.pointerId);if(pointers.size===1)gesture={panel:m.id,x:p.x,y:p.y,start:state.start,count:state.count,yZoom:m.yZoom||1,mode:m.kind==='price'&&p.x>m.geom.right?'scale':null,moved:false};else if(pointers.size===2){const [a,b]=[...pointers.values()];gesture={panel:m.id,start:state.start,count:state.count,mode:'pinch',distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),center:state.start+fraction((a.x+b.x)/2)*state.count,moved:true};}});
 el.addEventListener('pointermove',e=>{if(!m.geom)return;const p=xy(e);if(!pointers.has(e.pointerId)){if(e.pointerType==='mouse'){state.hover=Math.max(0,Math.min(state.dates.length-1,Math.round(state.start+fraction(p.x)*state.count-.5)));schedule();}return;}
  pointers.set(e.pointerId,p);if(!gesture||gesture.panel!==m.id)return;
  if(pointers.size===2){e.preventDefault();const [a,b]=[...pointers.values()],dist=Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),count=gesture.count*gesture.distance/dist,anchor=fraction((a.x+b.x)/2);Object.assign(state,N.clamp(gesture.center-count*anchor,count,state.dates.length));gesture.moved=true;sync();return;}
  if(gesture.mode==='pinch')return;const dx=p.x-gesture.x,dy=p.y-gesture.y;if(gesture.mode==='scale'){e.preventDefault();gesture.moved=true;m.yZoom=Math.max(.1,Math.min(10,gesture.yZoom*Math.exp(dy*.008)));schedule();return;}if(!gesture.mode&&Math.max(Math.abs(dx),Math.abs(dy))>7)gesture.mode=e.pointerType==='touch'&&Math.abs(dy)>Math.abs(dx)?'scroll':'pan';
  if(gesture.mode==='pan'){e.preventDefault();gesture.moved=true;state.start=N.clamp(gesture.start-dx/m.geom.width*gesture.count,state.count,state.dates.length).start;state.hover=null;sync();}
 },{passive:false});
 const end=e=>{const p=xy(e);if(gesture&&!gesture.moved&&gesture.mode!=='scroll'){state.hover=Math.max(0,Math.min(state.dates.length-1,Math.round(state.start+fraction(p.x)*state.count-.5)));m.article.querySelector('details').open=true;schedule();}pointers.delete(e.pointerId);if(el.hasPointerCapture(e.pointerId))el.releasePointerCapture(e.pointerId);if(!pointers.size)gesture=null;};
 el.addEventListener('pointerup',end);el.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);gesture=null;});el.addEventListener('lostpointercapture',e=>{pointers.delete(e.pointerId);if(!pointers.size)gesture=null;});
 el.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','+','=','-','Home','End'].includes(e.key)){e.preventDefault();if(e.key==='+'||e.key==='=')zoom(.7);else if(e.key==='-')zoom(1.4);else{state.start=e.key==='Home'?0:e.key==='End'?state.dates.length-state.count:state.start+(e.key==='ArrowLeft'?-1:1)*Math.max(1,state.count*.1);sync();}}});
}
$('index').onchange=()=>loadView();$('unit').onchange=()=>{scenarios();loadView();};$('scenario').onchange=()=>loadView();
for(const id of ['style','annotations','averages','log'])$(id).onchange=schedule;
document.querySelectorAll('[data-years]').forEach(b=>b.onclick=()=>years(b.dataset.years));$('zoom-in').onclick=()=>zoom(.7);$('zoom-out').onclick=()=>zoom(1.4);$('price-auto').onclick=()=>{for(const m of state.panels)m.yZoom=1;schedule();};
$('apply').onclick=()=>{const from=$('from').value,to=$('to').value,range=N.windowFor(state.dates,from,to);if(!from||!to||from>to||!range){setStatus('Choisis deux dates dans l’historique disponible.');return;}Object.assign(state,range);state.hover=null;setStatus('');sync();};
$('refresh').onclick=()=>location.reload();addEventListener('resize',schedule);addEventListener('blur',()=>{gesture=null;pointers.clear();});
if(compact())$('controls').open=false;
json('catalog.json').then(c=>{if(c.schemaVersion!==1)throw Error('Version de données incompatible');state.catalog=c;return loadView(true);}).catch(e=>setStatus(e.message));
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(()=>{});
})();
