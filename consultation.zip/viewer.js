'use strict';
const AWW_ANNUAL_VIEW=(()=>{function windowStats(rows,from,to){
 const lower=date=>{let a=0,b=rows.length;while(a<b){const m=(a+b)>>1;if(rows[m][0]<date)a=m+1;else b=m;}return a;};
 const first=from&&to?lower(from):rows.length,last=from&&to?lower(to+'\uffff')-1:-1;
 if(first>last)return {from:null,to:null,performance:[0,1,2].map(()=>({stats:{cagr:null,maxDrawdown:null,troughDate:null},mae:null}))};
 const a=rows[first],b=rows[last],years=(Date.parse(b[0])-Date.parse(a[0]))/(365.2425*86400000);
 const performance=[1,2,3].map(column=>{
  let peak=a[column],dd=0,troughDate=null,mae=null;
  for(let j=first;j<=last;j++){
   const r=rows[j],value=r[column];peak=Math.max(peak,value);
   const loss=peak>0?100*(value/peak-1):0;
   if(loss<dd){dd=loss;troughDate=r[0];}
   const adverse=column===1?null:r[column+2];
   if(Number.isFinite(adverse)&&(!mae||adverse<mae.percent))mae={percent:adverse,date:r[0]};
  }
  const cagr=years>0&&a[column]>0&&b[column]>=0?100*(Math.pow(b[column]/a[column],1/years)-1):null;
  return {stats:{from:a[0],to:b[0],cagr,maxDrawdown:dd,troughDate},mae};
 });
 return {from:a[0],to:b[0],performance};
}
/** Display an interval only as far as the visible right endpoint. Completed
 * values use exact execution observations supplied by the private observer;
 * an unfinished / clipped interval reads existing DAILY capital closes.
 * Both colours use system return minus unlevered Nasdaq, in percentage points.
 * No signals, thresholds or fund rules are calculated by this public helper.
 */
function periodValues(period,rows,to){
 if(period.complete&&period.to<=to)return {values:period.values,partial:false};
 let lo=0,hi=rows.length;while(lo<hi){const mid=(lo+hi)>>1;if(rows[mid][0]<=to)lo=mid+1;else hi=mid;}
 const row=rows[lo-1];if(!row||row[0]<period.from)return null;
 const returns=period.bases.map((base,i)=>base>0?100*(row[i+1]/base-1):null);
 return {values:returns.slice(1).map((v,i)=>period.tone==='b'&&i===0?null:v!==null&&returns[0]!==null?v-returns[0]:null),partial:true};
}
/** Compact one-line rail above the plot, shared verbatim by PC/public reader.
 * Whole-history / phone views cannot fit every short interval's text. Preserve
 * its coloured tick and reveal that interval on hover/touch, or when zoomed.
 * Prioritise the pointed interval, then red intervals, then available width;
 * never overlap labels or cover the capital curves or right-axis heading.
 */
function drawPeriods(c,m,g,x,indexAt,hoverDay,visible=true){
 m.periodLabels=[];m.periodTicks=[];if(!visible||!m.capitalPeriods?.length)return;
 const from=m.windowPerformance?.from,to=m.windowPerformance?.to;if(!from||!to)return;
 const small=g.w<600,font=(small?'600 10px':'600 11px')+' Segoe UI,Arial,sans-serif';
 c.save();c.font=font;c.textAlign='center';c.textBaseline='middle';
 // This rail is outside the cached plot. Clear it on hover too, without
 // repainting price data or the axis title at top - 11.
 c.clearRect(g.left,0,g.right-g.left,31);
 const signed=v=>Number.isFinite(v)?(v>0?'+':'')+v.toLocaleString('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1}):'—';
 const candidates=[];
 for(const p of m.capitalPeriods){
  if(p.from>to||p.to<from)continue;
  const left=Math.max(g.left,x(indexAt(p.from))),right=Math.min(g.right,p.complete?x(indexAt(p.to)):g.right);
  if(right<=left)continue;
  const observation=periodValues(p,m.windowData,to);if(!observation)continue;
  // Both systems hold the same daily inverse instrument in red intervals.
  // Show their common difference versus Nasdaq once, in points like blue.
  // Keep both observations for audits, never sum their differences.
  const suffix=observation.partial?'*':'',lines=['Δ '+signed(observation.values[p.tone==='r'?0:1])+' pt'+suffix];
  const width=Math.max(...lines.map(s=>c.measureText(s).width))+10,center=(left+right)/2,color=p.tone==='r'?'#ad4052':'#246fa9';
  const tick={from:p.from,to:p.to,tone:p.tone,left,right,center,color};m.periodTicks.push(tick);
  c.strokeStyle=color;c.globalAlpha=.55;c.lineWidth=2;c.beginPath();c.moveTo(center,g.top-5);c.lineTo(center,g.top);c.stroke();c.globalAlpha=1;
  candidates.push({...tick,lines,width,partial:observation.partial,values:observation.values,hover:!!hoverDay&&hoverDay>=p.from&&(hoverDay<p.to||!p.complete)});
 }
 candidates.sort((a,b)=>Number(b.hover)-Number(a.hover)||Number(b.tone==='r')-Number(a.tone==='r')||(b.right-b.left)-(a.right-a.left));
 for(const p of candidates){
  const left=Math.max(g.left,Math.min(g.right-p.width,p.center-p.width/2)),right=left+p.width;
  if(right>g.right||m.periodLabels.some(l=>left<l.right+5&&right>l.left-5))continue;
  const center=(left+right)/2,top=7,bottom=20;
  c.fillStyle=p.tone==='r'?'rgba(193,77,91,.06)':'rgba(22,117,197,.06)';c.fillRect(left,top,p.width,bottom-top);
  c.fillStyle=p.color;p.lines.forEach((line,i)=>c.fillText(line,center,top+7+i*13));
  c.strokeStyle=p.color;c.lineWidth=.7;c.globalAlpha=.5;c.beginPath();c.moveTo(center,bottom+2);c.lineTo(p.center,g.top-5);c.stroke();c.globalAlpha=1;
  m.periodLabels.push({...p,left,right,top,bottom});
 }c.restore();
}
/** H4 result, from the true entry base even when entry lies outside the zoom.
 * Final executions are separate from marks: at a reversal the exit-bar close
 * already includes the NEXT position. A clipped/open period reads only marks
 * known by `to`; the full-history final return must not leak into that prefix.
 */
function h4PeriodValues(period,series,to){
 if(to<period.from)return null;
 if(period.complete&&period.to<=to)return {values:period.values,partial:false};
 const values=series.map((s,j)=>{
  const ps=s.points;let lo=0,hi=ps.length;
  while(lo<hi){const mid=(lo+hi)>>1;if(ps[mid].date<=to)lo=mid+1;else hi=mid;}
  const row=ps[lo-1],base=period.bases[j];
  return row&&row.date>=period.from&&base>0?100*(row.v/base-1):null;
 });
 return {values,partial:true};
}
/** H4-only two-line rail. Same source on PC/public/phone. Curve colors identify
 * the two returns; the subtle connector identifies the position's background.
 * Crowded intervals keep a tick; hover/touch gives that interval priority.
 * Work in physical text pixels even on the PC's scaled mobile Canvas.
 */
function drawH4Periods(c,m,g,x,indexAt,from,to,hoverDay){
 m.h4PeriodLabels=[];m.h4PeriodTicks=[];if(!m.h4Periods?.length||!from||!to)return;
 const u=1/(g.uiScale||1),small=g.w/u<600;
 c.save();c.font='600 '+(small?10:11)*u+'px Segoe UI,Arial,sans-serif';c.textAlign='center';c.textBaseline='middle';
 c.clearRect(g.left,0,g.right-g.left,g.top-3*u);
 const signed=v=>Number.isFinite(v)?(v>0?'+':'')+v.toLocaleString('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1})+' %':'—';
 const candidates=[];
 for(const p of m.h4Periods){
  if(p.from>to||p.to<from)continue;
  const a=x(indexAt(p.from)),b=x(indexAt(p.to)+(p.complete?0:.5));
  if(b<g.left||a>g.right)continue;
  const left=Math.max(g.left,a),right=Math.min(g.right,b),center=(left+right)/2,observation=h4PeriodValues(p,m.series,to);
  if(!observation)continue;
  const lines=observation.values.map(v=>'Δ '+signed(v)+(observation.partial?'*':'')),colors=m.series.map(s=>s.color);
  const width=Math.max(...lines.map(s=>c.measureText(s).width))+8*u,color=p.tone==='v'?'#13846c':'#c14d5b';
  const tick={from:p.from,to:p.to,left,right,center,color};m.h4PeriodTicks.push(tick);
  c.strokeStyle=color;c.globalAlpha=.55;c.lineWidth=1.5*u;c.beginPath();c.moveTo(center,g.top-4*u);c.lineTo(center,g.top);c.stroke();c.globalAlpha=1;
  candidates.push({...tick,lines,colors,width,values:observation.values,partial:observation.partial,hover:!!hoverDay&&hoverDay>=p.from&&(hoverDay<p.to||!p.complete)});
 }
 candidates.sort((a,b)=>Number(b.hover)-Number(a.hover)||(b.right-b.left)-(a.right-a.left));
 for(const p of candidates){
  const left=Math.max(g.left,Math.min(g.right-p.width,p.center-p.width/2)),right=left+p.width;
  if(right>g.right||m.h4PeriodLabels.some(l=>left<l.right+4*u&&right>l.left-4*u))continue;
  const center=(left+right)/2,top=5*u,bottom=top+p.lines.length*13*u;
  p.lines.forEach((line,j)=>{c.fillStyle=p.colors[j];c.fillText(line,center,top+(6+j*13)*u);});
  c.strokeStyle=p.color;c.lineWidth=.6*u;c.globalAlpha=.45;c.beginPath();c.moveTo(center,bottom);c.lineTo(p.center,g.top-4*u);c.stroke();
  c.globalAlpha=1;m.h4PeriodLabels.push({...p,left,right,top,bottom});
 }c.restore();
}
return {windowStats,periodValues,drawPeriods,h4PeriodValues,drawH4Periods};})();
// Public shortcut: no notice below Capital, unlike the fully documented PC.
// Its top cannot always reach the sticky header before the page ends. Compare
// against the reachable scroll destination, not an unreachable viewport edge.
(()=>{
 if(typeof document==='undefined'||!document.body)return;
 function mount(){
  const charts=document.getElementById('charts');if(!charts)return;
  const nav=document.createElement('nav'),button=document.createElement('button');
  nav.id='chart-shortcuts';nav.setAttribute('aria-label','Accès rapide aux graphiques');
  button.id='chart-return';button.type='button';nav.append(button);document.body.append(nav);
  let target=null,frame=0;
  const desktop=matchMedia('(min-width:761px)');
  const offset=()=>Math.max(0,document.querySelector(desktop.matches?'.site-controls':'.quick')?.getBoundingClientRect().bottom||0)+12;
  const destination=element=>Math.min(Math.max(0,document.documentElement.scrollHeight-innerHeight),Math.max(0,scrollY+element.getBoundingClientRect().top-offset()));
  function update(){
   frame=0;
   // Index/timeframe changes replace the panels: always resolve current nodes.
   const price=charts.querySelector('.panel.price'),capital=charts.querySelector('[data-panel="equity"]');
   if(!price||!capital){target=null;nav.hidden=true;return;}
   const atCapital=scrollY>=destination(capital)-24;
   target=atCapital?price:capital;nav.hidden=false;
   const index=document.getElementById('index')?.selectedOptions[0]?.textContent||'Cours';
   const label=atCapital?(index==='Nasdaq 100'?'Nasdaq':index):'Capital';
   button.textContent=(atCapital?'↑ ':'↓ ')+label;
   button.title='Aller à · '+label;button.setAttribute('aria-label',button.title);
  }
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(update);};
  addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);
  new MutationObserver(schedule).observe(charts,{childList:true});
  button.addEventListener('click',()=>{if(target)scrollTo({top:destination(target),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});});
  update();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
// End public shortcut.
// Public gesture help: display-only text, never private rules or model fields.
// One delegated mouse tooltip survives panel replacement; touch remains clear.
(()=>{
 if(!document.body)return; // Calculation-only test DOM.
 function mount(){
  const charts=document.getElementById('charts');if(!charts)return;
  const help=document.createElement('div');help.id='chart-gesture-help';help.hidden=true;
  help.setAttribute('role','tooltip');document.body.append(help);let timer=0;
  const hide=()=>{clearTimeout(timer);help.hidden=true;};
  function queue(event){
   hide();const canvas=event.target.closest?.('canvas[data-chart-help]');
   if(!canvas||event.buttons||event.pointerType==='touch')return;
   const {clientX:x,clientY:y}=event;
   timer=setTimeout(()=>{
    if(!canvas.isConnected)return;
    help.replaceChildren(...canvas.dataset.chartHelp.split('\n').map(text=>{
     const line=document.createElement('div'),colon=text.indexOf(':');
     if(colon<0)line.textContent=text;
     else{const label=document.createElement('strong');label.textContent=text.slice(0,colon+1);line.append(label,document.createTextNode(text.slice(colon+1)));}
     return line;
    }));help.hidden=false;
    help.style.left=Math.max(8,Math.min(x+16,innerWidth-help.offsetWidth-8))+'px';
    help.style.top=Math.max(8,Math.min(y+18,innerHeight-help.offsetHeight-8))+'px';
   },900);
  }
  for(const name of ['pointermove','pointerup'])charts.addEventListener(name,queue,{passive:true});
  for(const name of ['pointerdown','pointerleave','pointercancel','wheel'])charts.addEventListener(name,hide,{passive:true});
  for(const name of ['scroll','resize','blur','keydown'])addEventListener(name,hide,{passive:true});
  new MutationObserver(hide).observe(charts,{childList:true});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
// End public gesture help.
/** Public display-only reader. Its inputs are already-computed curves, labels
 * and drawing geometry. No calls to a financial engine or external data API. */
// Canvas font lists must match viewer.css, including Arial/sans-serif fallback:
// iPhone has no Segoe UI. A single-family font can silently fall back to serif.
(()=>{
const $=id=>document.getElementById(id),N=AWW_VIEW_NAV,F=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}),compact=()=>innerWidth<=760;
const fmt=(x,d=2)=>Number.isFinite(x)?x.toLocaleString('fr-FR',{maximumFractionDigits:d}):'—',date=s=>s?s.slice(8,10)+'/'+s.slice(5,7)+'/'+s.slice(0,4)+(s.length>10?' '+s.slice(11,16)+' UTC':''):'—';
// Month names only in cursor labels; ISO dates and data navigation are unchanged.
const cursorDateFormat=new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
const cursorWeekdayFormat=new Intl.DateTimeFormat('fr-FR',{weekday:'long',timeZone:'UTC'});
const cursorDate=(d,weekday=false)=>{if(!d)return '—';const day=new Date(d.slice(0,10)+'T00:00:00Z'),hour=d.length>10?' '+Number(d.slice(11,13))+'h'+(d.slice(14,16)==='00'?'':d.slice(14,16))+' UTC':'';return (weekday?cursorWeekdayFormat.format(day)+' ':'')+cursorDateFormat.format(day)+hour;};
const state={cashSystem:'sys2',catalog:null,view:null,dates:[],times:[],panels:[],start:0,count:80,hover:null,cursor:null,raf:0,request:0,log:false};
const cache=new Map(),pointers=new Map();let gesture=null,observer=null;
// Display-only session history: ten actions plus the current view. Store tiny
// geometry snapshots, never panel data, signals or cursor movements. A gesture
// (pan, pinch, axis drag, navigator, wheel burst) commits once on release.
const viewHistory={context:'',items:[],index:-1,interaction:null,timer:null,restoring:false};
function rememberView(){
 if(!state.view||!state.dates.length)return;
 const h=viewHistory,context=[state.view.index,state.view.tf,state.view.calendar].join('|');
 const item={start:state.start,count:state.count,scales:state.panels.map(m=>[m.id,m.yZoom||1]),preset:state.periodPreset??null,yearWindow:state.yearWindow?{...state.yearWindow}:null};
 item.key=JSON.stringify([item.start,item.count,item.scales]);
 if(h.context!==context){clearTimeout(h.timer);Object.assign(h,{context,items:[item],index:0,interaction:null,timer:null});}
 else if(!h.restoring&&!h.interaction){
  if(h.items[h.index]?.key===item.key)h.items[h.index]=item;
  else{h.items=h.items.slice(0,h.index+1);h.items.push(item);if(h.items.length>11)h.items.shift();h.index=h.items.length-1;}
 }
 $('view-back').disabled=h.index<=0;$('view-forward').disabled=h.index>=h.items.length-1;
}
function beginViewAction(kind){if(viewHistory.interaction===kind)return;endViewAction();rememberView();viewHistory.interaction=kind;}
function endViewAction(){clearTimeout(viewHistory.timer);viewHistory.timer=null;if(viewHistory.interaction){viewHistory.interaction=null;rememberView();}}
function moveViewHistory(direction){
 endViewAction();rememberView();const h=viewHistory,next=h.index+direction;if(next<0||next>=h.items.length)return;
 const item=h.items[next];h.index=next;h.restoring=true;
 try{
  state.start=item.start;state.count=item.count;state.hover=null;state.cursor=null;
  const scales=new Map(item.scales);for(const m of state.panels){m.yZoom=scales.get(m.id)||1;delete m.sliderMarkers;}
  setPeriodPreset(item.preset);if(item.yearWindow)state.yearWindow={...item.yearWindow};sync(true);
 }finally{h.restoring=false;}
}
async function json(url){const r=await fetch(url,{cache:url==='catalog.json'?'no-cache':'default'});if(!r.ok)throw Error('Fichier indisponible ('+r.status+') : '+url);const raw=await r.text();
 if(url.startsWith('data/')){const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw));const hex=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');if(url!=='data/'+hex+'.json')throw Error('Données incomplètes : rechargez la page.');}
 return JSON.parse(raw);
}
async function chunk(url){if(!/^data\/[a-f0-9]{64}\.json$/.test(url))throw Error('Chemin de données invalide');if(!cache.has(url)){if(cache.size>45)cache.clear();cache.set(url,json(url).catch(e=>{cache.delete(url);throw e;}));}return cache.get(url);}
function scenarios(){
 const h4=$('unit').value==='h4',old=$('scenario').value,items=h4?[['v','Vert'],['r','Rouge'],['vr','Vert + rouge']]:[['sys1','SYS1'],['classic','SYS2']];
 $('scenario-control').hidden=!h4;$('scenario').replaceChildren(...items.map(([value,text])=>new Option(text,value)));
 if(h4&&items.some(x=>x[0]===old))$('scenario').value=old;
 if(!h4)$('scenario').value=state.cashSystem==='sys2'?'classic':'sys1';
 for(const [id,key] of [['system-1','sys1'],['system-2','sys2']]){const b=$(id);b.disabled=h4;b.classList.toggle('active',state.cashSystem===key);b.setAttribute('aria-pressed',String(state.cashSystem===key));}
}
function setSystem(system){if($('unit').value==='h4')return;state.cashSystem=system;scenarios();return loadView();}
function setStatus(text){$('status').textContent=text;}
async function loadView(initial=false){
 endViewAction();
 const request=++state.request,oldFrom=state.dates[Math.floor(state.start)]?.slice(0,10),oldTo=state.dates[Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1)]?.slice(0,10);
 // When following the newest prices, keep following them across timeframes:
 // an intraday snapshot can be newer than the last imported cash session. A user
 // inspecting the past keeps the historical window instead.
 const followLatest=state.dates.length>0&&state.start+state.count>=state.dates.length-1e-6;
 const v=state.catalog.views.find(v=>v.index===$('index').value&&v.tf===$('unit').value&&v.scenario===$('scenario').value);if(!v)return;
 setStatus('Chargement des résultats précalculés…');$('charts').classList.add('loading');
 try{
  const [dates,...panels]=await Promise.all([chunk(v.calendar),...v.panels.map(chunk)]);if(request!==state.request)return;
  const sameCalendar=state.view?.index===v.index&&state.view?.tf===v.tf&&state.view?.calendar===v.calendar;
  const retained=sameCalendar?{start:state.start,count:state.count,scales:new Map(state.panels.map(m=>[m.id,m.yZoom||1]))}:null;
  state.view=v;state.dates=dates;state.times=dates.map(Date.parse);state.panels=panels.map(p=>({...p,yZoom:retained?.scales.get(p.id)||1,...(p.capitalPeriods?{capitalPeriods:p.capitalPeriods[v.scenario==='sys1'?'sys1':'sys2']}:{}),series:p.series.map(s=>({...s,points:s.points.filter(r=>r[0]>=dates[0].slice(0,10)&&r[0]<=dates.at(-1)+'\uffff').map(([d,v])=>({date:d,v,i:N.position(state.times,Date.parse(d))}))})),candles:p.candles?.map(r=>({date:r[0],open:r[1],high:r[2],low:r[3],close:r[4],provisional:r[5],boost:r[6],i:N.position(state.times,Date.parse(r[0]))})),visible:true}));
  for(const m of state.panels){for(const s of m.series){s.indices=s.points.map(p=>p.i);s.dates=s.points.map(p=>p.date);}m.candleDates=m.candles?.map(r=>r.date);m.dcaDates=m.dca?.map(r=>r[0]);m.drawdownDates=m.drawdownSeries?.map(r=>r[0]);}
  state.hover=null;gesture=null;pointers.clear();
  let range=retained||(!initial&&oldFrom?N.windowFor(dates,oldFrom,followLatest?v.to.slice(0,10):oldTo):null);if(!range)range=compact()?{start:Math.max(0,dates.length-80),count:Math.min(80,dates.length)}:N.windowFor(dates,(+v.to.slice(0,4)-3)+v.to.slice(4,10),v.to.slice(0,10));
  Object.assign(state,N.clamp(range?.start||0,range?.count||dates.length,dates.length));
  $('coverage').textContent=date(v.from)+' → '+date(v.to)+' · '+fmt(v.bars)+' bougies · export du '+date(state.catalog.generatedAt);
  for(const id of ['from','to']){$(id).min=v.from.slice(0,10);$(id).max=v.to.slice(0,10);}
  $('end-year').replaceChildren(...[...new Set(dates.map(d=>d.slice(0,4)))].reverse().map(y=>new Option(y,y)));if(!sameCalendar)delete state.yearWindow;
  createPanels();sync(true);setStatus('');
 }catch(e){if(request===state.request)setStatus('Impossible de charger cette vue. '+e.message);}
 finally{if(request===state.request)$('charts').classList.remove('loading');}
}
function textNode(tag,text,cls){const e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;return e;}
function createPanels(){
 observer?.disconnect();$('charts').replaceChildren();
 $('charts').dataset.timeframe=state.view.tf; // Layout only; no extra field in public financial data.
 for(const m of state.panels){
  const article=document.createElement('article');article.className='panel '+(m.kind==='price'?'price':m.performance?'equity-comparison':m.id);if(m.performance){const header=textNode('div','','equity-head');header.append(textNode('h2','Capital'),equityControls(m));article.append(header);}else article.append(textNode('h2',m.title));
  article.dataset.panel=m.id;
  if(m.regimes){
   const bar=textNode('div','','prophet-chart-tools'),label=textNode('label','Filtre','prophet-direction-control'),select=document.createElement('select');select.id='chart-direction';select.setAttribute('aria-label','Filtre du graphique');
   for(const [value,text] of [['v','Vert'],['r','Rouge'],['vr','Vert + rouge']])select.append(new Option(text,value));select.value=state.view.scenario;select.onchange=()=>{$('scenario').value=select.value;return loadView();};label.append(select);bar.append(label);
   if(m.h4Lines){const key=textNode('div','','h4-line-key');key.setAttribute('aria-label','TL');for(const code of ['EX','AC','PT'])key.append(textNode('span',code,code.toLowerCase()));bar.append(key);}
   const regimes=textNode('div','','prophet-regimes');regimes.append(textNode('span','NDX'));
   for(const r of m.regimes){const box=textNode('div','','regime '+(r.position>0?'long':r.position<0?'short':'flat')),text=r.position===null?'—':r.position>0?'V '+Math.round(r.position*100)+' %':r.position<0?'R':'B';box.append(textNode('strong',r.label+' · '+text),textNode('small',date(r.asOf)));regimes.append(box);}bar.append(regimes);article.append(bar);
  }
  const metrics=textNode('div','','metrics');m.metrics=metrics;article.append(metrics);
  const plot=textNode('div','','chart'),canvas=document.createElement('canvas');canvas.tabIndex=0;canvas.setAttribute('role','img');canvas.setAttribute('aria-label',m.title+' : flèches pour parcourir, + et − pour zoomer');canvas.dataset.panel=m.id;plot.append(canvas);article.append(plot);m.canvas=canvas;
  {const nav=textNode('div','','navigator');nav.append(textNode('span','Parcourir'));const input=document.createElement('input');input.type='range';input.id=m.kind==='price'?'navigator':'navigator-'+m.id;m.navigator=input;input.setAttribute('aria-label','Parcourir l’historique · '+m.title);input.min=0;input.step=.1;bindNavigator(input);nav.append(input);article.append(nav);}
  $('charts').append(article);m.article=article;bind(m);
 }
 if('IntersectionObserver' in window){observer=new IntersectionObserver(entries=>{for(const e of entries){const m=state.panels.find(m=>m.canvas===e.target);if(m)m.visible=e.isIntersecting;}schedule();},{rootMargin:'250px'});state.panels.forEach(m=>observer.observe(m.canvas));}
}
// Every panel slider mirrors the same window, including after pan, pinch or a view change.
// Only an explicit preset selection is highlighted. Any manual date/zoom/pan
// action clears it, including at the data boundary; repaint/hover do not.
function setPeriodPreset(value=null){
 delete state.yearWindow;
 state.periodPreset=value===null?null:String(value);
 document.querySelectorAll('[data-years]').forEach(b=>{const on=b.dataset.years===state.periodPreset;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
}
function sync(keepPreset=false){if(!keepPreset)setPeriodPreset();Object.assign(state,N.clamp(state.start,state.count,state.dates.length));$('from').value=state.dates[Math.floor(state.start)]?.slice(0,10)||'';$('to').value=state.dates[Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1)]?.slice(0,10)||'';$('end-year').value=$('to').value.slice(0,4);for(const m of state.panels){const slider=m.navigator;slider.max=Math.max(0,state.dates.length-state.count);slider.value=state.start;slider.disabled=state.count>=state.dates.length;slider.setAttribute('aria-valuetext',date($('from').value)+' → '+date($('to').value));}rememberView();schedule();}
function schedule(){if(!state.raf)state.raf=requestAnimationFrame(()=>{state.raf=0;for(const m of state.panels){if(m.visible)paint(m);}});}
function zoom(f,anchor=.5){Object.assign(state,N.zoom(state.start,state.count,state.dates.length,f,anchor));state.hover=null;sync();}
function zoomRight(f){endViewAction();Object.assign(state,N.zoomRight(state.start,state.count,state.dates.length,f));state.hover=null;state.cursor=null;sync();}
function years(value){endViewAction();const v=state.view;if(!v)return;const range=value==='all'?{start:0,count:state.dates.length}:N.windowFor(state.dates,(+v.to.slice(0,4)-Number(value))+v.to.slice(4,10),v.to.slice(0,10));if(range){
 // Presets also release manual price-axis stretching on desktop and phone.
 for(const m of state.panels)if(m.kind==='price')m.yZoom=1;
 Object.assign(state,range);state.hover=null;state.cursor=null;setPeriodPreset(value);sync(true);}}
function endAtYear(year){
 endViewAction();
 const window=state.yearWindow||{count:state.count,preset:state.periodPreset},range=N.endingYear(state.dates,year,window.count);if(!range)return;
 for(const m of state.panels){m.yZoom=1;delete m.sliderMarkers;}
 Object.assign(state,range);state.hover=null;state.cursor=null;
 setPeriodPreset(range.count===window.count?window.preset:null);state.yearWindow=window;sync(true);
}
const pos=d=>N.position(state.times,Date.parse(d));
// Calendar span, independent of bar count or zoom. Clamp month ends rather than
// letting Date roll e.g. 31 October back into July when subtracting four months.
// Precomputed confirmed outcomes only; no trading rule or threshold in this reader.
// Cash decisions belong to the following UTC day on CFD H4, like the native
// dailyPlotIndex. Filter outside the calendar before position() clamps its ends.
const regimePlotDate=d=>state.view.tf==='h4'?new Date(Date.parse(d)+86400000).toISOString():d;
function drawADRegimeMarkers(c,m,g,x,end){
 m.regimeMarkerLayout=[];if(!m.regimeMarkers?.length)return;
 end=state.view.tf==='h4'?new Date(Date.parse(end.slice(0,10))-86400000).toISOString().slice(0,10):end;
 c.save();c.lineWidth=1.5;c.globalAlpha=.8;c.lineCap='round';
 for(const mark of m.regimeMarkers){
  const plotted=regimePlotDate(mark.date),time=Date.parse(plotted);
  if(mark.knownAt>end||time<state.times[0]||time>state.times.at(-1))continue;
  const xx=x(pos(plotted));if(xx<g.left+4||xx>g.right-4)continue;
  const yy=g.top+28,dir=mark.side==='up'?-1:1;
  c.strokeStyle=mark.color;c.beginPath();c.moveTo(xx,yy-dir*6);c.lineTo(xx,yy+dir*6);c.moveTo(xx-3.5,yy+dir*2);c.lineTo(xx,yy+dir*6);c.lineTo(xx+3.5,yy+dir*2);c.stroke();
  m.regimeMarkerLayout.push({...mark,x:xx,y:yy});
 }
 c.restore();
}
function visibleZones(zones,end){const groups=new Map();for(const z of zones||[])if(z.knownAt<=end){const old=groups.get(z.group);if(!old||old.knownAt<=z.knownAt)groups.set(z.group,z);}return [...groups.values()].filter(z=>!z.hidden);}
// Coordinates and codes are supplied by the PC. This renderer only clips and
// styles them: no detection, eligibility/counting, projection or market rule.
function drawH4Lines(c,m,g,x,y,end){
 m.h4LineLayout=[];
 for(const l of m.h4Lines||[]){
  const [u,v]=l.ends,a=pos(u[0]),b=pos(v[0]);
  const fade=l.code==='EX'?1:Math.max(0,1-Math.max(g.left-x(b),x(b)-g.right,0)/42);
  if(!fade||a>=state.start+state.count||l.code==='EX'&&(l.knownAt>end||b<state.start-1))continue;
  if(l.code!=='EX'&&l.knownAt!==state.dates.at(-1))continue;
  const left=Math.max(a,state.start-1),right=Math.min(b,state.start+state.count),value=(i,k)=>u[k]+(v[k]-u[k])*(i-a)/(b-a);
  const executed=l.code==='EX',dash=executed?[]:l.code==='AC'?[7,4]:[1,5],alpha=executed?1:l.code==='AC'?.9:.48;
  c.save();c.strokeStyle=l.color;c.lineWidth=executed?2:l.code==='AC'?1.5:1;c.globalAlpha=alpha*fade;c.setLineDash(dash);
  if(executed){c.fillStyle=l.color+'1f';c.beginPath();c.moveTo(x(left),y(value(left,2)));c.lineTo(x(right),y(value(right,2)));c.lineTo(x(right),y(value(right,3)));c.lineTo(x(left),y(value(left,3)));c.closePath();c.fill();}
  for(const k of executed?[1]:[2,3]){c.beginPath();c.moveTo(x(left),y(value(left,k)));c.lineTo(x(right),y(value(right,k)));c.stroke();}
  c.setLineDash([]);c.fillStyle=executed?l.color:'#fff';
  for(const [d,v] of l.dots){const xx=x(pos(d));if(xx<g.left||xx>g.right)continue;c.beginPath();c.arc(xx,y(v),executed?2.4:2.6,0,2*Math.PI);c.fill();if(!executed)c.stroke();}
  c.restore();m.h4LineLayout.push({line:l,dash,alpha,fade,x:x(b),y:y(l.labelAt[1])});
 }
}
function drawH4LineLabels(c,m,g,candles){
 const previous=m.h4LabelLayout||[],boxes=(m.markerLayout||[]).map(p=>p.box).filter(Boolean);m.h4LabelLayout=[];
 const hits=box=>candles.some(p=>box.left<p.right+8&&box.right>p.left-8&&box.top<p.bottom+8&&box.bottom>p.top-8);
 c.save();c.font='600 10px Segoe UI,Arial,sans-serif';c.textAlign='center';c.textBaseline='middle';
 for(const p of m.h4LineLayout||[]){
  if(p.line.code==='EX')continue; // Existing EX # marker identifies this line.
  const old=previous.find(v=>v.line===p.line),preferred=old?{left:old.left+p.x-old.x,right:old.right+p.x-old.x,top:old.top+p.y-old.y,bottom:old.bottom+p.y-old.y}:null;
  const box=placeEquityLabel(p.x,p.y,c.measureText(p.line.code).width+10,17,g,boxes,hits,preferred);if(!box)continue;
  boxes.push(box);const xx=(box.left+box.right)/2,yy=(box.top+box.bottom)/2;
  c.strokeStyle=p.line.color;c.lineWidth=1;c.globalAlpha=.65*p.fade;c.setLineDash([3,3]);c.beginPath();c.moveTo(xx,yy);c.lineTo(p.x,p.y);c.stroke();c.setLineDash([]);c.globalAlpha=p.fade;
  c.fillStyle='rgba(255,255,255,.6)';c.fillRect(box.left,box.top,box.right-box.left,box.bottom-box.top);c.fillStyle=p.line.color;c.fillText(p.line.code,xx,yy);
  m.h4LabelLayout.push({...p,...box});
 }c.restore();
}
// Historical decoration only. The builder supplies dates and final colours;
// no private rule or colour derived from a future outcome before its knownAt.
function drawDivergenceFrames(c,m,g,x,end){
 m.divergenceFrameLayout=[];if(m.id!=='ad')return;
 c.save();c.font='bold 10px Segoe UI,Arial,sans-serif';c.textAlign='center';c.setLineDash([]);c.lineWidth=.8;
 const lanes=[[],[]];
 for(const z of visibleZones(m.zones,end)){
  if(!z.framedAt||regimePlotDate(z.framedAt)>end)continue;
  const a=x(pos(z.from)),b=x(pos(z.to));if(b<g.left||a>g.right)continue;
  const outcome=z.outcome&&regimePlotDate(z.outcome.knownAt)<=end?z.outcome:null;
  const label='D−'+(outcome?' · NDX '+fmt(outcome.percent,1)+' %':''),w=c.measureText(label).width+10,cx=Math.max(g.left+w/2+2,Math.min(g.right-w/2-2,(Math.max(g.left,a)+Math.min(g.right,b))/2));
  const lane=lanes.findIndex(items=>items.every(q=>cx+w/2+4<q[0]||cx-w/2-4>q[1]));if(lane<0)continue;
  lanes[lane].push([cx-w/2,cx+w/2]);const yy=g.top+4+lane*18;
  if(outcome){c.fillStyle=outcome.fill;c.fillRect(cx-w/2,yy,w,15);}
  c.fillStyle=outcome?.ink||z.color;c.strokeStyle=z.color;c.strokeRect(cx-w/2,yy,w,15);c.fillText(label,cx,yy+11);
  m.divergenceFrameLayout.push({from:z.from,to:z.to,framedAt:z.framedAt,label,outcome,x:cx-w/2,y:yy,w,h:15});
 }c.restore();
}
function drawDowKey(c,m,g){
 const s=m.series.find(s=>s.key==='dow');if(!s)return;
 c.save();c.font='10px Segoe UI,Arial,sans-serif';c.fillStyle=s.color;c.strokeStyle=s.color;c.lineWidth=1.4;c.setLineDash([]);
 const xx=g.left+7,yy=g.bottom-(compact()?25:9);c.beginPath();c.moveTo(xx,yy-3);c.lineTo(xx+12,yy-3);c.stroke();c.textAlign='left';c.fillText('Dow',xx+16,yy);c.restore();
}
function getSlice(series){const a=Math.max(0,N.lower(series.indices,state.start)-1),b=N.lower(series.indices,state.start+state.count)+1;return series.points.slice(a,b);}
function scale(values,log,zero){let lo=Infinity,hi=-Infinity;for(const v of values)if(Number.isFinite(v)&&(!log||v>0)){lo=Math.min(lo,v);hi=Math.max(hi,v);}if(lo===Infinity){lo=0;hi=1;log=false;}if(zero&&!log){lo=Math.min(0,lo);hi=Math.max(0,hi);}if(log){lo=Math.log(lo);hi=Math.log(hi);}const margin=(hi-lo)*.10||Math.abs(hi)*.05||1;return {lo:lo-margin,hi:hi+margin,log};}
/** Place a symbol + caption outside nearby candle wicks. This is screen-space
 * layout only: dates, execution prices and financial results never change.
 * Crowded zoomed-out views keep symbols; captions reappear as space permits. */
function markerLayout(items,candles,bounds,measure,showText){
 const placed=[],overlaps=(a,b)=>a.left<b.right+3&&a.right>b.left-3&&a.top<b.bottom+3&&a.bottom>b.top-3;
 const priority=m=>m.peer?2:m.shape==='mm200'?3:m.shape==='bam'||m.shape==='bam-reference'?1:0;
 for(const item of [...items].sort((a,b)=>priority(a.mark)-priority(b.mark)||a.x-b.x)){
  const mark=item.mark,above=mark.side==='down'||mark.side==='neutral'||mark.shape==='exit';
  let candidate=null;
  // Compact captions only. No trading instructions exist in the public data.
  const variants=showText||item.outcome?[true,...(!mark.labelOnly?[false]:[])]:mark.labelOnly?[]:[false];
  for(const caption of variants){
   const width=caption?Math.max(14,measure(mark.label)+10,item.outcome?measure('Δ '+fmt(item.outcome.percent,1)+' %')+10:0):12,height=caption?30+(item.outcome?14:0):12;
   if(width>bounds.right-bounds.left-4)continue;
   // A numeric TP caption near the right edge can be trapped between the
   // last candle and an earlier signal. Try adjacent columns before hiding it.
   // The dashed leader stays attached to the original date/level.
   const centers=[...new Set((mark.shape==='tp'&&caption?[item.x,item.x-width-8,item.x+width+8]:[item.x]).map(x=>Math.max(bounds.left+width/2+2,Math.min(bounds.right-width/2-2,x))))];
   for(const center of centers){
   const near=candles.filter(r=>r.right>=center-width/2-3&&r.left<=center+width/2+3);
   const high=Math.min(item.y,...near.map(r=>r.top)),low=Math.max(item.y,...near.map(r=>r.bottom));
   for(const sign of [above?-1:1,above?1:-1]){
    for(let lane=0;lane<6;lane++){
     const tip=(sign<0?high-12:low+12)+sign*lane*(height+4);
     const box={left:center-width/2,right:center+width/2,top:sign<0?tip-height:tip,bottom:sign<0?tip:tip+height};
     if(box.top<bounds.top+2||box.bottom>bounds.bottom-2)continue;
     if(placed.some(p=>overlaps(box,p.box))||near.some(r=>overlaps(box,r)))continue;
     candidate={...item,center,tip,sign,caption,box};break;
    }if(candidate)break;
   }if(candidate)break;
   }if(candidate)break;
  }
  if(candidate)placed.push(candidate);
 }
 return placed;
}
/** Range sliders move every chart. Keep already placed/hidden captions stable
 * relative to their candles until release, instead of re-solving collisions on
 * every input tick. This memory is presentation only and never exported.
 * Known labels may finish crossing the edge; release restores the date cutoff. */
function bindNavigator(input){
 let active=false;
 const begin=()=>{if(active)return;beginViewAction('slider');active=true;const asOf=state.dates[Math.min(state.dates.length-1,Math.floor(state.start+state.count-1))];
  for(const m of state.panels)if(m.kind==='price'){
   const placements=new Map((m.markerItems||[]).map(p=>[p.mark,null]));
   for(const p of m.markerLayout||[])placements.set(p.mark,p);
   m.sliderMarkers={asOf,placements};
  }
 };
 const end=()=>{if(!active)return;active=false;for(const m of state.panels)delete m.sliderMarkers;endViewAction();schedule();};
 input.onpointerdown=e=>{if(e.button===0)begin();};
 input.onkeydown=e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','PageUp','PageDown','Home','End'].includes(e.key))begin();else if(e.key==='Escape')end();};
 input.oninput=()=>{begin();state.start=+input.value;state.hover=null;state.cursor=null;sync();};
 input.onchange=input.onpointerup=input.onpointercancel=input.onlostpointercapture=input.onblur=end;
}
function sliderMarkerLayout(m,items,candles,bounds,measure,showText){
 if(!m.sliderMarkers)return markerLayout(items,candles,bounds,measure,showText);
 const cache=m.sliderMarkers.placements,placed=[];
 for(const item of items){
  if(!cache.has(item.mark))cache.set(item.mark,markerLayout([item],candles,bounds,measure,showText)[0]||null);
  const old=cache.get(item.mark);if(!old)continue;
  const dx=item.x-old.x,dy=item.y-old.y,box={left:old.box.left+dx,right:old.box.right+dx,top:old.box.top+dy,bottom:old.box.bottom+dy};
  // Retain the leader as well as the caption until the whole drawing leaves.
  if(Math.max(item.x,box.right)<bounds.left||Math.min(item.x,box.left)>bounds.right||Math.max(item.y,box.bottom)<bounds.top||Math.min(item.y,box.top)>bounds.bottom)continue;
  placed.push({...old,x:item.x,y:item.y,center:old.center+dx,tip:old.tip+dy,box});
 }
 return placed;
}
/** Pure glyph drawing: the export supplies the meaning/colour. A text-only
 * sequence and a participation arrow must never become extra sell triangles. */
function drawMarkerSymbol(c,mark,xx,cy){
 if(mark.labelOnly)return;
 c.strokeStyle=mark.color;c.fillStyle=(mark.hollow??mark.peer)?'white':mark.color;c.lineWidth=1.5;
 c.setLineDash(mark.provisional||mark.hollow?[2,2]:[]);c.beginPath();
 if(mark.shape==='exit'){c.moveTo(xx-4,cy-4);c.lineTo(xx+4,cy+4);c.moveTo(xx-4,cy+4);c.lineTo(xx+4,cy-4);}
 else if(mark.shape==='mm200'){
  const dir=mark.side==='up'?-1:1,tip=cy+dir*5;
  c.moveTo(xx,cy-dir*5);c.lineTo(xx,tip);c.moveTo(xx-4,tip-dir*4);c.lineTo(xx,tip);c.lineTo(xx+4,tip-dir*4);
 }else if(mark.shape==='bam'||mark.shape==='bam-reference'){c.moveTo(xx,cy-5);c.lineTo(xx+5,cy);c.lineTo(xx,cy+5);c.lineTo(xx-5,cy);c.closePath();c.fill();}
 else if(mark.shape==='circle'||mark.shape==='tp'){c.arc(xx,cy,5,0,Math.PI*2);c.fill();}
 else if(mark.shape==='square'){c.rect(xx-5,cy-5,10,10);c.fill();}
 else{const direction=mark.side==='down'||mark.side==='neutral'?1:-1;c.moveTo(xx,cy+5*direction);c.lineTo(xx-5,cy-4*direction);c.lineTo(xx+5,cy-4*direction);c.closePath();c.fill();}
 c.stroke();c.setLineDash([]);
}
// Display only: no financial calculation. The fixed card uses canvas bounds;
// the five historical arrows follow their own curve and disappear outside zoom.
// Presentation preferences survive timeframe/scenario changes, never enter the
// financial cache or public data export. Hidden series retain their original data.
const equityView={hidden:new Set(),singleScale:true};
function equityEntries(m){return m.performance.map((p,i)=>({p,i})).filter(({p})=>!equityView.hidden.has(p.key));}
function equityMargin(m,w){const n=equityEntries(m).length;return n?(w<600?31:42)*(equityView.singleScale?1:n)+6:8;}
// Display-only rebasing. Keep raw points and raw-coordinate ranges so curves,
// historical DD/MAE arrows and collision geometry all retain the same mapping.
// The first visible observation is 100, independently for each strategy.
function equityValue(m,i,value){const base=m.equityBases?.[i]?.value;return base>0?value/(base/100):value;}
function equityRanges(m,points,start,end=Infinity){
 const slices=m.series.map(points);
 m.equityBases=slices.map(ps=>{const p=ps.find(p=>(p.idx??p.i)>=start-.5&&Number.isFinite(p.v));return {value:p?.v,date:p?.date};});
 // Bind statistics to the actual plotted endpoint dates, not padded calendar
 // limits. All daily closes inside those endpoints remain available in weekly.
 const from=m.equityBases[0]?.date,to=slices[0]?.findLast(p=>(p.idx??p.i)<=end+.5&&Number.isFinite(p.v))?.date;
 const cache=m.windowCache;
 if(m.windowData&&(!cache||cache.data!==m.windowData||cache.from!==from||cache.to!==to)){
  m.windowPerformance=AWW_ANNUAL_VIEW.windowStats(m.windowData,from,to);
  m.windowCache={data:m.windowData,from,to};
 }
 const offsets=m.equityBases.map(b=>b.value>0?Math.log(b.value/100):0);
 const values=slices.map((ps,i)=>ps.map(p=>p.v).filter(v=>Number.isFinite(v)&&v>0).map(v=>Math.log(v)-offsets[i]));
 const extent=vs=>{const lo=vs.length?Math.min(...vs):0,hi=vs.length?Math.max(...vs):1,pad=(hi-lo)*.09||.1;return {min:lo-pad,max:hi+pad};};
 const shared=equityView.singleScale?extent(equityEntries(m).flatMap(({i})=>values[i])):null;
 return values.map((vs,i)=>{const r=shared||extent(vs);return {min:r.min+offsets[i],max:r.max+offsets[i]};});
}
function setEquityDisplay(key,checked){
 if(key==='singleScale')equityView.singleScale=checked;
 else if(checked)equityView.hidden.delete(key);else equityView.hidden.add(key);
}
function equityControls(m){
 const controls=textNode('div','','equity-controls');controls.setAttribute('role','group');controls.setAttribute('aria-label','Courbes et échelle des courbes de capital');
 const choices=m.performance.map((p,i)=>({key:p.key,label:['B&H','SYS1','SYS2'][i],title:p.label,color:p.color,checked:!equityView.hidden.has(p.key)}));
 choices.push({key:'singleScale',label:'Échelle unique',title:'Cochée : graphe semi-logarithmique avec une échelle commune. Décochée : une échelle adaptative par courbe.',color:'#52677c',checked:equityView.singleScale});
 for(const o of choices){const label=textNode('label',''),input=document.createElement('input');label.title=o.title;label.style.color=o.color;input.type='checkbox';input.id='equity-show-'+o.key;input.checked=o.checked;input.onchange=()=>{setEquityDisplay(o.key,input.checked);paint(m);};label.append(input,textNode('span',o.label));controls.append(label);}
 return controls;
}
// Context uses the already plotted exposure, not new trade rules. The steps
// match the panel above (end-of-day / end-of-week), including intermediate 50% -> 100%.
// Shared backdrop for Nasdaq, exposure and capital. Read only the selected
// exposure series (cash SYS1/SYS2, or Prophet in H4); never infer trades from
// price colours. Cached steps retain the regime already active at the left edge.
// Keep the historic equityExposure* cache names for the rendering contract.
function drawEquityExposure(c,m,g,x,points=[]){
 // H4 uses only the selected, already exported position series. Zero has no
 // tint; positive/negative use green/red. Cash daily/weekly stays red/blue.
 const h4=state.view.tf==='h4';
 if(m.equityExposureSource!==points){
  m.equityExposureSource=points;m.equityExposureSteps=[];let previous=null;
  for(const p of points){if(!Number.isFinite(p.v)||p.v===previous)continue;m.equityExposureSteps.push({index:p.idx??p.i,value:p.v,buy:p.v>0&&(previous===null||p.v>previous)});previous=p.v;}
 }
 const steps=m.equityExposureSteps;m.equityExposureLayout=[];
 if(m.performance&&!equityEntries(m).length)return;
 c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
 for(let i=0;i<steps.length;i++){
  const p=steps[i],a=x(p.index),b=i+1<steps.length?x(steps[i+1].index):g.right;
  const left=Math.max(g.left,a),right=Math.min(g.right,b);
  if(right>left&&(h4?p.value!==0:p.value<=0)){
   const kind=p.value<0?'short':p.value>0?'long':'flat';
   c.fillStyle=kind==='short'?'rgba(193,77,91,.07)':kind==='long'?'rgba(19,132,108,.07)':'rgba(22,117,197,.085)';
   c.fillRect(left,g.top,right-left,g.bottom-g.top);m.equityExposureLayout.push({kind,left,right,index:p.index});
  }
  if(m.performance&&p.buy&&a>=g.left&&a<=g.right){c.strokeStyle='rgba(19,132,108,.25)';c.lineWidth=1;c.setLineDash(p.value<100?[3,3]:[]);c.beginPath();c.moveTo(a,g.top);c.lineTo(a,g.bottom);c.stroke();m.equityExposureLayout.push({kind:'buy',x:a,index:p.index,value:p.value});}
 }c.restore();
}
// Hover labels read existing capital observations. Labels share a compact
// right-hand stack when curves are close; connector dots retain their true y.
// Both readers call this on the interaction layer so mouse movement does not
// invalidate the private renderer's cached financial/annotation background.
function drawEquityHover(c,m,g,x,index,day){
 m.equityHoverLabels=[];
 if(index===null||index===undefined||x(index)<g.left||x(index)>g.right)return;
 const labels=[],height=20,gap=3;
 c.save();c.font=(g.w<600?'600 10px':'600 11px')+' Segoe UI,Arial,sans-serif';c.textBaseline='middle';
 for(const {p,i} of equityEntries(m)){
  const points=m.series[i].points;let a=0,b=points.length;
  while(a<b){const mid=(a+b)>>1;if((points[mid].idx??points[mid].i)<=index)a=mid+1;else b=mid;}
  const point=points[a-1],range=m.seriesRanges[i];if(!point||!(point.v>0))continue;
  const xx=x(point.idx??point.i),yy=g.bottom-(Math.log(point.v)-range.min)/(range.max-range.min)*(g.bottom-g.top);
  if(xx<g.left||xx>g.right||yy<g.top||yy>g.bottom)continue;
  const value=equityValue(m,i,point.v),text=['B&H','SYS1','SYS2'][i]+' '+fmt(value,0),width=Math.min(g.w-20,c.measureText(text).width+12),right=compact()?g.right-3:g.w-3;
  labels.push({key:p.key,color:p.color,value,date:point.date,index:point.idx??point.i,x:xx,y:yy,text,width,right,left:right-width,top:Math.max(g.top,Math.min(g.bottom-height,yy-height/2))});
 }
 labels.sort((a,b)=>a.y-b.y);
 for(let i=1;i<labels.length;i++)labels[i].top=Math.max(labels[i].top,labels[i-1].top+height+gap);
 for(let i=labels.length-1;i>=0;i--)labels[i].top=Math.min(labels[i].top,i===labels.length-1?g.bottom-height:labels[i+1].top-height-gap);
 for(const l of labels){
  c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();c.strokeStyle=l.color;c.globalAlpha=.45;c.lineWidth=1;c.setLineDash([3,3]);c.beginPath();c.moveTo(l.x,l.y);c.lineTo(g.right,l.y);c.stroke();c.restore();
  c.fillStyle=l.color;c.beginPath();c.arc(l.x,l.y,3,0,Math.PI*2);c.fill();
  c.strokeStyle=l.color;c.lineWidth=1;c.setLineDash([]);c.beginPath();c.moveTo(g.right,l.y);c.lineTo(l.left,l.top+height/2);c.stroke();
  c.fillStyle=compact()?'rgba(255,255,255,.4)':l.color;c.fillRect(l.left,l.top,l.width,height);c.fillStyle=compact()?l.color:'#fff';c.textAlign='left';c.fillText(l.text,l.left+6,l.top+height/2,l.width-12);
  l.bottom=l.top+height;
 }
 if(labels.length){const text=cursorDate(day,state.view.tf!=='weekly'),width=c.measureText(text).width+12,xx=Math.max(g.left+width/2,Math.min(g.right-width/2,x(index)));c.fillStyle='#15356b';c.fillRect(xx-width/2,g.bottom+(compact()?15:5),width,compact()?14:20);c.fillStyle='#fff';c.textAlign='center';c.fillText(text,xx,g.bottom+(compact()?22:15));}
 c.restore();m.equityHoverLabels=labels;
}
function equityTick(v){return v>=1e9?fmt(v/1e9,0)+'G':v>=1e6?fmt(v/1e6,0)+'M':v>=1e3?fmt(v/1e3,0)+'k':fmt(v,0);}
// Measure each inset axis including its title, rather than allocating a
// fixed 48 px column. Preserve the B&H/SYS1/SYS2 order with a 4 px clear gap.
// All positions are drawing coordinates: no financial series are transformed.
function drawEquityAxes(c,m,g){
 const {left,right,top,bottom,w}=g,inside=compact(),step=w<600?31:42;
 c.save();c.font=(w<600?'700 9px':'600 10px')+' Segoe UI,Arial,sans-serif';
 for(let j=0;j<=2;j++){const yy=bottom-(bottom-top)*j/2;c.strokeStyle='#e9eef4';c.beginPath();c.moveTo(left,yy);c.lineTo(right,yy);c.stroke();}
 const entries=equityEntries(m),axes=equityView.singleScale?entries.slice(0,1):entries;
 // A quiet 100 reference makes the window origin readable without clipping
 // any fall below the initial capital. Independent axes keep their own ticks.
 m.equityBaseLine=null;
 if(equityView.singleScale&&entries.length){const i=entries[0].i,r=m.seriesRanges[i],base=m.equityBases[i].value;
  if(base>0){const yy=bottom-(Math.log(base)-r.min)/(r.max-r.min)*(bottom-top);
   if(yy>=top&&yy<=bottom){c.save();c.strokeStyle='#c1ccd8';c.setLineDash([2,4]);c.beginPath();c.moveTo(left,yy);c.lineTo(right,yy);c.stroke();c.fillStyle='#60758a';c.textAlign='left';c.fillText('100',left+4,Math.max(top+11,yy-5));c.restore();m.equityBaseLine={value:100,y:yy};}
  }
 }
 const columns=axes.map(({p,i})=>{const r=m.seriesRanges[i],title=equityView.singleScale?'Base 100':['B&H','SYS1','SYS2'][i],ticks=Array.from({length:3},(_,j)=>equityTick(equityValue(m,i,Math.exp(r.min+(r.max-r.min)*j/2))));
  // On phones the lowest tick gets its own row below the plot; dates sit
  // one row lower. This frees the card to sit just 5 px above the axis.
  const tickYs=ticks.map((_,j)=>inside?(j===0?bottom+11:Math.max(top+11,bottom-(bottom-top)*j/2+3)):bottom-(bottom-top)*j/2+3);
  return {p,i,title,ticks,tickYs,width:Math.ceil(Math.max(...[title,...ticks].map(t=>c.measureText(t).width)))};});
 let edge=right-4;
 for(let j=columns.length-1;j>=0;j--){const col=columns[j];col.x=inside?edge:right+step*(j+.5)+3;col.left=inside?edge-col.width:col.x-col.width/2;col.right=inside?edge:col.x+col.width/2;edge=col.left-4;}
 m.equityAxisCount=columns.length;m.equityAxisLayout=columns.map(({p,i,...layout})=>layout);
 for(const col of columns){c.textAlign=inside?'right':'center';c.globalAlpha=inside?.7:1;c.fillStyle=equityView.singleScale?'#52677c':col.p.color;c.fillText(col.title,col.x,top-11);
  col.ticks.forEach((label,j)=>c.fillText(label,col.x,col.tickYs[j]));
 }c.restore();
}
function equityCard(c,m,g){
 const small=g.w<600,pad=8,main=(small?'700 10px':'600 12px')+' Segoe UI,Arial,sans-serif',sub=(small?'600 9px':'500 10px')+' Segoe UI,Arial,sans-serif';
 const lines=equityEntries(m).map(({p,i})=>{const {stats,mae}=m.windowPerformance?.performance[i]||p;return {color:p.color,main:'CAGR '+['B&H','SYS1','SYS2'][i]+' : '+fmt(stats.cagr,2)+' %/an',sub:'MDD '+fmt(stats.maxDrawdown,2)+' %'+(p.key==='buyHold'?'':' · MAE '+fmt(mae?.percent,2)+' %')};});
 const period='Période : '+date((m.windowPerformance||m.stats).from)+' – '+date((m.windowPerformance||m.stats).to);let width=0;
 c.save();c.font=main;for(const l of lines)width=Math.max(width,c.measureText(l.main).width);c.font=sub;for(const l of lines)width=Math.max(width,c.measureText(l.sub).width);width=Math.max(width,c.measureText(period).width);c.restore();
 width=Math.min(width+pad*2,g.right-g.left-8);const height=24+29*lines.length;
 // Bottom ticks are below the mobile plot. Keep a small gap above its axis,
 // with the card fixed in the viewport while dates move underneath it.
 const bottomGap=5;
 return {left:g.right-width-4,right:g.right-4,top:g.bottom-height-bottomGap,bottom:g.bottom-bottomGap,width,height,pad,main,sub,lines,period};
}
function drawEquityCard(c,m,g){
 if(!equityEntries(m).length){m.equityCardBounds=null;c.save();c.fillStyle='#52677c';c.font='12px Segoe UI,Arial,sans-serif';c.textAlign='center';c.fillText('Sélectionnez une courbe dans le titre.',(g.left+g.right)/2,(g.top+g.bottom)/2);c.restore();return;}
 const b=equityCard(c,m,g);m.equityCardBounds=b;
 c.save();c.fillStyle=compact()?'rgba(255,255,255,.4)':'rgba(248,250,253,.84)';c.fillRect(b.left,b.top,b.width,b.height);c.strokeStyle=compact()?'rgba(89,113,138,.2)':'#dbe2ec';c.strokeRect(b.left,b.top,b.width,b.height);c.textAlign='left';c.textBaseline='middle';
 b.lines.forEach((l,i)=>{const yy=b.top+13+i*29;c.fillStyle=l.color;c.font=b.main;c.fillText(l.main,b.left+b.pad,yy,b.width-2*b.pad);c.font=b.sub;c.fillText(l.sub,b.left+b.pad,yy+12,b.width-2*b.pad);});
 c.fillStyle='#52677c';c.font='9px Segoe UI,Arial,sans-serif';c.fillText(b.period,b.left+b.pad,b.bottom-9,b.width-2*b.pad);c.restore();
}
// Project every visible curve into narrow screen columns once per redraw.
// Keeping separate envelopes per curve preserves empty space between curves.
// Candidate labels then avoid all traces (including segments between samples),
// the fixed statistics card and one another, with an 8 px visual clearance.
function equityCurveObstacles(m,g,x){
 const step=4,n=Math.ceil((g.right-g.left)/step)+1,bands=[];
 for(const {i} of equityEntries(m)){
  const lo=new Float64Array(n).fill(Infinity),hi=new Float64Array(n).fill(-Infinity),r=m.seriesRanges[i];let prev=null;
  for(const p of m.series[i].points){
   if(!(p.v>0)||!Number.isFinite(p.v)){prev=null;continue;}
   const q={x:x(p.idx??p.i),y:g.bottom-(Math.log(p.v)-r.min)/(r.max-r.min)*(g.bottom-g.top)};
   const a=prev||q,b=q;prev=q;
   if(b.x<g.left||a.x>g.right)continue;
   const left=Math.max(g.left,a.x),right=Math.min(g.right,b.x),first=Math.max(0,Math.floor((left-g.left)/step)),last=Math.min(n-1,Math.floor((right-g.left)/step));
   for(let j=first;j<=last;j++){
    const l=Math.max(left,g.left+j*step),rr=Math.min(right,g.left+(j+1)*step),dy=b.y-a.y,dx=b.x-a.x;
    const yl=dx?a.y+(l-a.x)*dy/dx:a.y,yr=dx?a.y+(rr-a.x)*dy/dx:b.y;
    lo[j]=Math.min(lo[j],yl,yr);hi[j]=Math.max(hi[j],yl,yr);
   }
  }bands.push({lo,hi});
 }
 return box=>{
  const pad=8,first=Math.max(0,Math.floor((box.left-pad-g.left)/step)),last=Math.min(n-1,Math.floor((box.right+pad-g.left)/step));
  for(const {lo,hi} of bands)for(let j=first;j<=last;j++)if(lo[j]<=box.bottom+pad&&hi[j]>=box.top-pad)return true;
  return false;
 };
}
function placeEquityLabel(px,py,width,height,g,boxes,hitsCurve,preferred){
 // Keep the same 8 px clearance at the plot edges as around curves;
 // a faded label near the edge must not touch a curve entering the viewport.
 const clampX=v=>Math.max(g.left+8,Math.min(g.right-width-8,v)),xs=new Set([clampX(px-width/2)]),ys=new Set(),candidates=[];
 for(let left=g.left+8;left<=g.right-width-8;left+=Math.max(24,width/2))xs.add(left);
 xs.add(g.right-width-8);
 for(const dy of [-50,50,-76,76])ys.add(py+dy-height/2);
 for(let top=g.top+8;top<=g.bottom-height-8;top+=height+7)ys.add(top);
 const overlap=(a,b)=>a.left<b.right+5&&a.right>b.left-5&&a.top<b.bottom+5&&a.bottom>b.top-5;
 // Reuse the offset while it is still clear: hover and small pans must not
 // shuffle labels merely because another candidate became slightly closer.
 if(preferred&&preferred.left>=g.left+8&&preferred.right<=g.right-8&&preferred.top>=g.top+8&&preferred.bottom<=g.bottom-8&&!boxes.some(b=>overlap(preferred,b))&&!hitsCurve(preferred))return preferred;
 for(const left of xs)for(const top of ys){
  if(left<g.left+8||top<g.top+8||top+height>g.bottom-8)continue;
  const dx=left+width/2-px,dy=top+height/2-py;
  if(Math.abs(dy)<34&&Math.abs(dx)<width/2+34)continue;
  const box={left,right:left+width,top,bottom:top+height};
  candidates.push({box,score:Math.hypot(dx,dy)+(dy>0?12:0)});
 }
 candidates.sort((a,b)=>a.score-b.score);
 for(const {box} of candidates)if(!boxes.some(b=>overlap(box,b))&&!hitsCurve(box))return box;
 return null; // Never force text onto a trace; the fixed card retains the value.
}
function drawEquityExtremes(c,m,g,x){
 const card=equityCard(c,m,g),boxes=[card],layout=[],hitsCurve=equityCurveObstacles(m,g,x),previous=m.equityMarkLayout||[];
 c.save();c.font=(g.w<600?'700 9px':'600 11px')+' Segoe UI,Arial,sans-serif';c.textAlign='center';c.textBaseline='middle';
 equityEntries(m).forEach(({p,i})=>{
  const ps=m.series[i].points,r=m.seriesRanges[i],{stats,mae}=m.windowPerformance?.performance[i]||p;
  for(const [kind,eventDate,percent] of [['DD',stats.troughDate,stats.maxDrawdown],['MAE',mae?.date,mae?.percent]]){
   if(!eventDate||!Number.isFinite(percent)||percent>=0||(p.key==='buyHold'&&kind==='MAE'))continue;
   // Weekly: attach to the plotted bar containing the daily extreme. The
   // percentage/date remain daily statistics, never recomputed from weekly bars.
   let a=0,b=ps.length;while(a<b){const mid=(a+b)>>1;if(ps[mid].date<eventDate)a=mid+1;else b=mid;}
   const point=ps[a];if(!point||!(point.v>0))continue;
   const px=x(point.idx??point.i),py=g.bottom-(Math.log(point.v)-r.min)/(r.max-r.min)*(g.bottom-g.top);
   if(px<g.left||px>g.right||py<g.top||py>g.bottom)continue;
   const label=(kind==='DD'?'MDD':kind)+' '+['B&H','SYS1','SYS2'][i]+' '+fmt(percent,2)+' %',width=c.measureText(label).width+10,height=17;
   const old=previous.find(l=>l.key===p.key&&l.kind===kind&&l.date===eventDate),preferred=old?{left:old.left+(px-old.x),right:old.right+(px-old.x),top:old.top+(py-old.y),bottom:old.bottom+(py-old.y)}:null;
   const box=placeEquityLabel(px,py,width,height,g,boxes,hitsCurve,preferred);
   if(!box)continue;
   // Fade through the last 48 screen pixels before the historical point
   // leaves the time window. Opacity follows the pan; no timer or financial work.
   const edge=Math.max(0,Math.min(1,Math.min(px-g.left,g.right-px)/48)),opacity=edge*edge*(3-2*edge);
   boxes.push(box);layout.push({key:p.key,kind,date:eventDate,plotDate:point.date,percent,x:px,y:py,opacity,...box});
   c.globalAlpha=opacity;
   const lx=(box.left+box.right)/2,ly=(box.top+box.bottom)/2,sy=ly<py?box.bottom:box.top,angle=Math.atan2(py-sy,px-lx);
   c.strokeStyle=p.color;c.lineWidth=1.25;c.setLineDash([2,2]);c.beginPath();c.moveTo(lx,sy);c.lineTo(px,py);c.stroke();c.setLineDash([]);
   c.beginPath();c.moveTo(px-5*Math.cos(angle-.5),py-5*Math.sin(angle-.5));c.lineTo(px,py);c.lineTo(px-5*Math.cos(angle+.5),py-5*Math.sin(angle+.5));c.stroke();
   c.fillStyle='rgba(255,255,255,.4)';c.fillRect(box.left,box.top,width,height);c.fillStyle=p.color;c.fillText(label,lx,ly);
  }
 });c.restore();m.equityMarkLayout=layout;
}

// Free cursor level: display geometry only. Unlike a series value, this follows
// the pointer vertically so a wick's high/low can be read on mouse or touch.
function drawLevelHover(c,m,g,primary,secondary,hasSecondary,primaryLeft){
 m.levelHoverLabels=[];
 const pointer=state.cursor;
 if(m.performance||state.hover===null||pointer?.panel!==m.id||pointer.x<g.left||pointer.x>g.right||pointer.y<g.top||pointer.y>g.bottom)return;
 const yy=pointer.y,inside=compact(),height=18;
 c.save();c.font=(inside?'600 10px':'600 11px')+' Segoe UI,Arial,sans-serif';c.textBaseline='middle';c.strokeStyle='rgba(63,94,130,.6)';c.lineWidth=1;c.setLineDash([3,3]);c.beginPath();c.moveTo(g.left,yy);c.lineTo(g.right,yy);c.stroke();c.setLineDash([]);
 function label(s,isLeft){const raw=s.hi-(yy-g.top)/(g.bottom-g.top)*(s.hi-s.lo),value=s.log?Math.exp(raw):raw,text=fmt(value,0)+(m.id==='position'?' %':''),width=c.measureText(text).width+10;
  const left=isLeft?(inside?g.left+3:Math.max(0,g.left-width-3)):(inside?g.right-width-3:Math.min(g.w-width,g.right+3)),top=Math.max(g.top,Math.min(g.bottom-height,yy-height/2));
  c.fillStyle=inside?'rgba(255,255,255,.4)':'#15356b';c.fillRect(left,top,width,height);c.fillStyle=inside?'#294d74':'white';c.textAlign='left';c.fillText(text,left+5,top+height/2);m.levelHoverLabels.push({value,text,left,right:left+width,top,bottom:top+height});
 }
 label(primary,primaryLeft);if(hasSecondary)label(secondary,!primaryLeft);
 // One line in the original axis margin; weekday and hour use the candle's UTC date.
 const text=cursorDate(state.dates[state.hover],state.view.tf!=='weekly'),width=c.measureText(text).width+10,xx=Math.max(g.left+width/2,Math.min(g.right-width/2,g.x(state.hover))),dateTop=g.h-24;c.fillStyle='#15356b';c.fillRect(xx-width/2,dateTop,width,18);c.fillStyle='white';c.textAlign='center';c.fillText(text,xx,dateTop+9);c.restore();
}
// Shared calendar geometry aligns Jan 1 across every panel, even when the
// displayed series is daily/weekly within another price timeframe. Interpolate
// a holiday between sessions; never use an arbitrary tick as an annual boundary.
function drawCalendarYears(c,m,g){
 m.yearSeparators=[];c.save();c.strokeStyle=m.kind==='price'?'#b9c7d7':'#d5dbe2';c.lineWidth=1;
 const first=state.times[0],last=state.times.at(-1);
 for(let year=+state.dates[0].slice(0,4);year<=+state.dates.at(-1).slice(0,4);year++){
  const day=year+'-01-01',time=Date.parse(day+'T00:00:00Z');if(time<first||time>last)continue;
  const xx=g.x(N.position(state.times,time));if(xx<g.left||xx>g.right)continue;
  c.beginPath();c.moveTo(xx,g.top);c.lineTo(xx,g.bottom);c.stroke();m.yearSeparators.push({date:day,x:xx});
 }c.restore();
}
function paint(m){
 const canvas=m.canvas,w=canvas.clientWidth,h=canvas.clientHeight;if(!w||!h)return;const ratio=Math.min(devicePixelRatio||1,3);if(canvas.width!==Math.round(w*ratio)||canvas.height!==Math.round(h*ratio)){canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);}const c=canvas.getContext('2d');c.setTransform(ratio,0,0,ratio,0,0);c.clearRect(0,0,w,h);
 const small=w<600,inside=compact(),left=inside?10:m.performance?24:68,right=inside?w-10:w-(m.performance?equityMargin(m,w):79),top=(m.performance||m.h4Periods)?48:16,bottom=h-(m.dca?82:30),width=right-left,height=bottom-top;if(width<10||height<10)return;
 const x=i=>left+(i-state.start+.5)/state.count*width,at=i=>state.dates[Math.max(0,Math.min(state.dates.length-1,Math.floor(i)))],end=at(state.start+state.count-1),hasLast=state.start+state.count>=state.dates.length-.1;
 const candles=(m.candles||[]).filter(r=>r.i>=state.start-1&&r.i<=state.start+state.count),all=m.series.map(s=>({...s,visible:getSlice(s)}));
 const primary=scale([...all.filter(s=>s.axis!=='secondary'&&!(m.kind==='price'&&s.key==='close')).flatMap(s=>s.visible.map(p=>p.v)),...candles.flatMap(r=>[r.low,r.high]),...(m.kind!=='price'?all.filter(s=>s.axis!=='secondary').flatMap(s=>s.visible.map(p=>p.v)):[])],m.kind==='price'?true:m.log,m.zero);
 if(m.kind==='price'){const space=(primary.hi-primary.lo)*.055;primary.lo-=space;primary.hi+=space;}
 if(m.kind==='price'&&m.yZoom){const mid=(primary.hi+primary.lo)/2,half=(primary.hi-primary.lo)*m.yZoom/2;primary.lo=mid-half;primary.hi=mid+half;}
 if(m.id==='position'){primary.lo=-110;primary.hi=110;primary.log=false;}
 const secondary=scale(all.filter(s=>s.axis==='secondary').flatMap(s=>s.visible.map(p=>p.v)),false,false),yOf=(v,s)=>top+(s.hi-(s.log?Math.log(v):v))/(s.hi-s.lo)*height,y=v=>yOf(v,primary),sy=v=>yOf(v,secondary);
 m.geom={left,right,top,bottom,width,x,w,h};
 if(m.performance)m.seriesRanges=equityRanges(m,s=>all[m.series.indexOf(s)].visible,state.start,state.start+state.count-1);c.font=(small?'700 10px':'600 11px')+' Segoe UI,Arial,sans-serif';c.lineWidth=1;
 const hasSecondary=all.some(s=>s.axis==='secondary'),primaryLeft=hasSecondary&&m.id==='ad';
 const ticksFor=s=>m.id==='position'?(m.series.some(s=>s.points.some(p=>p.v===-50))?[-100,-50,0,50,100]:[-100,0,50,100]).map(v=>({v,y:yOf(v,s)})):Array.from({length:5},(_,j)=>{const raw=s.hi-(s.hi-s.lo)*j/4;return {v:s.log?Math.exp(raw):raw,y:top+height*j/4};});
 m.axisTicks=ticksFor(primary);
 m.axisLabelLayout=[];
 // Exposure labels sit towards the inside of the +/-100 plateaus, not on
 // the coloured stroke. Keep the grid at its exact percentage coordinates.
 function axis(s,isLeft){c.save();c.textAlign=inside?(isLeft?'left':'right'):(isLeft?'right':'left');c.globalAlpha=inside?.7:1;
  if(!m.performance)for(const tick of ticksFor(s)){const exposure=inside&&m.id==='position',yy=exposure?tick.y+(tick.v===-100?-10:10):inside?Math.max(top+11,Math.min(bottom-3,tick.y+4)):tick.y+4;
   c.textBaseline=exposure?'middle':'alphabetic';c.fillStyle='#59718a';c.fillText(fmt(tick.v,0)+(m.id==='position'?' %':''),inside?(isLeft?left+4:right-4):(isLeft?left-6:right+6),yy);m.axisLabelLayout.push({value:tick.v,y:yy,lineY:tick.y});
  }c.restore();}
 if(!m.performance)for(const tick of m.axisTicks){c.strokeStyle='#e7eef5';c.beginPath();c.moveTo(left,tick.y);c.lineTo(right,tick.y);c.stroke();}if(m.performance)drawEquityAxes(c,m,m.geom);else axis(primary,primaryLeft);if(hasSecondary)axis(secondary,!primaryLeft);
 // Fixed ticks show complete years in every timeframe; the cursor retains date/time.
 c.textAlign='center';const ticks=Math.max(2,Math.floor(width/(small?90:120))),seen=new Set();for(let j=0;j<=ticks;j++){const i=Math.min(state.dates.length-1,Math.floor(state.start+(state.count-1)*j/ticks)),d=at(i);const label=d.slice(0,4);if(!seen.has(label)){c.fillStyle='#59718a';c.fillText(label,Math.max(left+20,Math.min(right-23,x(i))),m.performance&&inside?bottom+26:h-8);seen.add(label);}}
 c.save();c.beginPath();c.rect(left,top,width,height);c.clip();
 if(['price-ndx','position','equity'].includes(m.id))drawEquityExposure(c,m,m.geom,x,state.panels.find(p=>p.id==='position')?.series[0].points||[]);
 drawCalendarYears(c,m,m.geom);
 for(const z of visibleZones(m.zones,end)){const a=x(pos(z.from)),b=x(pos(z.to));if(b<left||a>right)continue;c.fillStyle=z.shade;c.fillRect(a,z.lane==='lower'?top+height/2:top,b-a,z.lane==='lower'?height/2:height);if(Number.isFinite(z.a)&&Number.isFinite(z.b)){c.strokeStyle=z.color;c.setLineDash([]);c.beginPath();c.moveTo(a,y(z.a));c.lineTo(b,y(z.b));c.stroke();}if(hasSecondary&&Number.isFinite(z.priceA)&&Number.isFinite(z.priceB)){c.strokeStyle=z.color;c.setLineDash([4,3]);c.beginPath();c.moveTo(a,sy(z.priceA));c.lineTo(b,sy(z.priceB));c.stroke();}c.setLineDash([]);}
 if(m.zero){c.strokeStyle='#7495ba';c.setLineDash([3,3]);c.beginPath();c.moveTo(left,y(0));c.lineTo(right,y(0));c.stroke();c.setLineDash([]);}
 if(m.h4Lines)drawH4Lines(c,m,m.geom,x,y,end);
 for(const s of all){if(m.performance&&equityView.hidden.has(s.key))continue;if(m.kind==='price'&&s.key==='close')continue;const range=m.performance?m.seriesRanges[all.indexOf(s)]:null,yy=range?(v=>bottom-(Math.log(v)-range.min)/(range.max-range.min)*height):s.axis==='secondary'?sy:y;
  c.strokeStyle=s.color;c.fillStyle=s.color;c.lineWidth=s.width||1.35;c.setLineDash(s.dash?[4,3]:[]);c.beginPath();let prev=null;
  for(let j=0;j<s.visible.length;j++){const p=s.visible[j];if(!Number.isFinite(p.v)||primary.log&&s.axis!=='secondary'&&p.v<=0){prev=null;continue;}const xx=x(p.i),py=yy(p.v);
   if(s.bar){const neighbor=s.visible[j+1]||s.visible[j-1],spacing=neighbor?Math.abs(x(neighbor.i)-xx):width/state.count,bw=Math.min(24,Math.max(1.5,spacing*.78));c.fillStyle=p.v>=0?s.positiveColor||s.color:s.negativeColor||'#d64564';c.fillRect(xx-bw/2,Math.min(py,yy(0)),bw,Math.max(1,Math.abs(py-yy(0))));}
   else{if(prev&&(!s.gap||Date.parse(p.date)-Date.parse(prev.date)<=s.gap)){if(s.signed){c.stroke();c.beginPath();c.strokeStyle=p.v>=0?'#13846c':'#c14d5b';c.moveTo(x(prev.i),yy(prev.v));}if(s.step)c.lineTo(xx,yy(prev.v));c.lineTo(xx,py);}else c.moveTo(xx,py);prev=p;}
  }if(!s.bar)c.stroke();c.setLineDash([]);
 }
 if(m.kind==='price'){
  const bw=Math.max(.8,Math.min(15,width/state.count*.68));for(const r of candles){const xx=x(r.i),up=r.close>=r.open;c.strokeStyle=r.provisional?'#b57312':up?'#242a32':'#bc4657';c.fillStyle=up?'white':'#e78694';c.lineWidth=1;c.setLineDash(r.provisional?[2,2]:[]);c.beginPath();c.moveTo(xx,y(r.high));c.lineTo(xx,y(r.low));c.stroke();const py=Math.min(y(r.open),y(r.close)),ph=Math.max(1,Math.abs(y(r.close)-y(r.open)));c.fillRect(xx-bw/2,py,bw,ph);if(r.boost){c.strokeStyle='#198754';c.lineWidth=2;}c.strokeRect(xx-bw/2,py,bw,ph);}c.setLineDash([]);c.lineWidth=1;
 }
 m.tpLevelLayout=[];
 if(m.id==='ad'||m.id==='hl'){drawDowKey(c,m,m.geom);drawDivergenceFrames(c,m,m.geom,x,end);}
 {
  drawADRegimeMarkers(c,m,{left,right,top,bottom},x,end);
  for(const s of m.segments){if(s.knownAt>end||s.to<at(state.start)||s.from>end)continue;const a=pos(s.from),b=pos(s.to),last=Math.min(b,state.start+state.count-.5),value=s.a+(s.b-s.a)*(last-a)/(b-a||1);c.strokeStyle=s.color;c.setLineDash(s.dash?[3,3]:[]);c.beginPath();c.moveTo(x(a),y(s.a));c.lineTo(x(last),y(value));c.stroke();}c.setLineDash([]);
  const candlePixels=candles.map(r=>({left:x(r.i)-Math.max(1,width/state.count*.4),right:x(r.i)+Math.max(1,width/state.count*.4),top:y(r.high),bottom:y(r.low)}));
  const frozen=m.sliderMarkers;if(frozen&&end>frozen.asOf)frozen.asOf=end;
  const annotationEnd=frozen?.asOf||end;
  const items=m.markers.filter(mark=>mark.knownAt<=annotationEnd).map(mark=>({mark,outcome:mark.outcome&&regimePlotDate(mark.outcome.knownAt)<=annotationEnd?mark.outcome:null,i:pos(mark.date),x:x(pos(mark.date)),y:y(mark.value)})).filter(p=>(p.i>=state.start&&p.i<state.start+state.count||frozen?.placements.has(p.mark))&&Number.isFinite(p.y));
  m.markerItems=items;
  // Historical TP levels are supplied by the export; never derive a target here.
  // Keep the stroke even if the collision solver suppresses a crowded caption.
  for(const p of items){if(p.mark.shape!=='tp'||!Number.isFinite(p.mark.triggerValue))continue;
   const yy=y(p.mark.triggerValue),a=Math.max(left,p.x-36),b=Math.min(right,p.x+36);if(yy<top||yy>bottom||b<=a)continue;
   c.save();c.strokeStyle=p.mark.color;c.lineWidth=1.2;c.setLineDash([3,3]);c.beginPath();c.moveTo(a,yy);c.lineTo(b,yy);c.stroke();c.restore();
   m.tpLevelLayout.push({date:p.mark.date,value:p.mark.triggerValue,executionValue:p.mark.executionValue,left:a,right:b,y:yy});
  }
  m.markerLayout=sliderMarkerLayout(m,items,candlePixels,{left,right,top,bottom},s=>c.measureText(s).width,state.count<650);
  for(const p of m.markerLayout){const mark=p.mark,xx=p.center,tip=p.tip,sign=p.sign;
   c.strokeStyle=mark.color;c.lineWidth=1;c.setLineDash([2,3]);c.globalAlpha=.55;c.beginPath();c.moveTo(p.x,Math.max(top,Math.min(bottom,p.y)));c.lineTo(xx,tip-sign*3);c.stroke();c.globalAlpha=1;c.setLineDash(mark.provisional?[2,2]:[]);
   drawMarkerSymbol(c,mark,xx,tip+sign*5);
   if(p.caption){const baseline=sign>0?tip+25:p.box.top+11,extra=p.outcome?14:0;c.fillStyle=p.outcome?.fill||'#ffffffdf';c.fillRect(p.box.left,baseline-10,p.box.right-p.box.left,14+extra);c.fillStyle=p.outcome?.ink||mark.color;c.textAlign='center';c.fillText(mark.label,xx,baseline);
    if(p.outcome)c.fillText('Δ '+fmt(p.outcome.percent,1)+' %',xx,baseline+14);
   }
  }
  if(m.h4Lines)drawH4LineLabels(c,m,m.geom,candlePixels);
  // The 30% frame is a price-chart aid, regardless of signal/regime colour.
  // Transparent interior: preserve candles and keep capital DD/MAE unchanged.
  m.correctionLabelLayout=[];
  for(const dd of m.drawdowns||[]){
   if(dd.confirmed>end)continue;const xx=x(pos(dd.date));if(xx<left||xx>right)continue;
   const label=fmt(dd.percent,1)+' %',framed=dd.percent<-30,w=c.measureText(label).width+10;
   const cx=framed?Math.max(left+w/2+1,Math.min(right-w/2-1,xx)):xx,yy=Math.max(top+13,Math.min(bottom-5,y(dd.value)+25));
   c.fillStyle=dd.tone==='r'?'#c14d5b':dd.tone==='b'?'#1675c5':'#c47b21';
   if(framed){c.strokeStyle=c.fillStyle;c.lineWidth=1;c.setLineDash([]);c.strokeRect(cx-w/2,yy-12,w,16);}
   c.textAlign='center';c.fillText(label,cx,yy);m.correctionLabelLayout.push({date:dd.date,percent:dd.percent,framed,x:cx-w/2,y:yy-12,w,h:16});
  }
 }
 c.restore();
 if(m.performance){drawEquityExtremes(c,m,m.geom,x);drawEquityCard(c,m,m.geom);}
 if(m.dca){
  // Inset labels stay at the left so the latest (rightmost) state remains visible.
  const railLabel=(label,yy)=>{c.save();c.textAlign=inside?'left':'right';c.fillStyle='#52677c';if(inside){c.strokeStyle='rgba(255,255,255,.7)';c.lineWidth=2;c.strokeText(label,left+4,yy);}c.fillText(label,inside?left+4:left-5,yy);c.restore();};
  const rails=[['AD cum.',m.ribbons?.ad],['NH−NL',m.ribbons?.hl]];rails.forEach(([label,zs],j)=>{const yy=bottom+9+j*12;c.fillStyle='#eaf0f5';c.fillRect(left,yy,width,7);for(const z of visibleZones(zs,end)){const a=Math.max(left,x(pos(z.from))),b=Math.min(right,x(pos(z.to)));if(b>a){c.fillStyle=z.color+'88';c.fillRect(a,yy,b-a,7);}}railLabel(label,yy+7);});
  const yy=bottom+34;let segment=null;const flush=()=>{if(!segment)return;const a=Math.max(left,segment.a),b=Math.min(right,segment.b);if(b<=a)return;c.fillStyle=segment.color;c.fillRect(a,yy,b-a,12);if(b-a>27){c.fillStyle=segment.label==='M'?'#285337':'white';c.textAlign='center';c.fillText(segment.label,(a+b)/2,yy+10);}};
  for(const [d,label,color] of m.dca){const i=pos(d);if(i<state.start-1||i>state.start+state.count)continue;const a=x(i)-width/state.count/2,b=a+width/state.count;if(segment?.label===label)segment.b=b;else{flush();segment={a,b,label,color};}}flush();
  for(const [d] of m.bams||[]){const xx=x(pos(d));if(xx>=left&&xx<=right){c.fillStyle='#f0cc25';c.fillRect(xx-2,yy,4,12);}}
  railLabel('DCA',yy+9);
 }
 if(state.hover!==null){const xx=x(state.hover);if(xx>=left&&xx<=right){c.strokeStyle='#567ba0';c.setLineDash([3,3]);c.beginPath();c.moveTo(xx,top);c.lineTo(xx,bottom);c.stroke();c.setLineDash([]);}}
 if(m.performance){
  drawEquityHover(c,m,m.geom,x,state.hover,state.dates[state.hover]);
  AWW_ANNUAL_VIEW.drawPeriods(c,m,m.geom,x,d=>Math.ceil(pos(d)),state.dates[state.hover],equityEntries(m).length>0);
 }
 if(m.h4Periods)AWW_ANNUAL_VIEW.drawH4Periods(c,m,m.geom,x,d=>Math.ceil(pos(d)),at(state.start-.5),at(state.start+state.count-.5),state.dates[state.hover]);
 drawLevelHover(c,m,m.geom,primary,secondary,hasSecondary,primaryLeft);
 m.metrics.replaceChildren();if(m.stats&&!m.performance){const s=m.stats;m.metrics.append(textNode('span',Number.isFinite(s.cagr)?(m.cagrLabel||'CAGR')+' '+fmt(s.cagr)+' %':'Perf. '+fmt(s.cumulativeReturnPct)+' %'),textNode('span','MDD '+fmt(s.maxDrawdown??s.maxDrawdownPct)+' %'),textNode('span','Période · '+date(s.from)+' — '+date(s.to)));}
 if(hasLast&&m.kind==='price'){
  for(const r of m.readouts||[]){const span=textNode('span',r.text);span.style.color=r.color;m.metrics.append(span);}
  if(m.currentDrawdown){const span=textNode('span','DD '+fmt(m.currentDrawdown.percent)+' %');span.style.color='#cd7a16';m.metrics.append(span);}
 }
}
/** Describe this reader's actual handlers, not the PC's richer gestures.
 * Public charts pan/zoom time; only price charts resize via the right axis.
 * No rectangle zoom, vertical panning or double-click reset exists here.
 */
function chartGestureHelp(m){
 const rows=['Survol : lire la date et les valeurs.','Glisser : parcourir les dates.','Molette : zoomer dans le temps.'];
 if(m.kind==='price')rows.push('Axe droit : glisser pour ajuster les prix.');
 else if(m.id==='position')rows.push('Échelle : graduations fixes.');
 else if(m.performance)rows.push('Échelles : ajustement automatique selon les courbes cochées.');
 else if(m.id==='ad'||m.id==='hl')rows.push((m.id==='ad'?'A/D':'NH−NL')+' : échelle automatique.','Dow : échelle automatique.');
 else rows.push('Échelle : ajustement automatique.');
 return rows.join('\n');
}
function bind(m){const el=m.canvas;
 el.title='';el.dataset.chartHelp=chartGestureHelp(m);
 const xy=e=>{const r=el.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};};
 const fraction=x=>Math.max(0,Math.min(1,(x-m.geom.left)/m.geom.width));
 el.addEventListener('wheel',e=>{if(!m.geom)return;e.preventDefault();beginViewAction('wheel');zoom(Math.exp(Math.max(-200,Math.min(200,e.deltaY))*.002),fraction(xy(e).x));clearTimeout(viewHistory.timer);viewHistory.timer=setTimeout(endViewAction,400);},{passive:false});
 el.addEventListener('pointerdown',e=>{if(!m.geom||e.button!==0)return;beginViewAction('pointer');const p=xy(e);pointers.set(e.pointerId,p);el.setPointerCapture(e.pointerId);if(pointers.size===1)gesture={panel:m.id,x:p.x,y:p.y,start:state.start,count:state.count,yZoom:m.yZoom||1,mode:m.kind==='price'&&p.x>m.geom.right?'scale':null,moved:false};else if(pointers.size===2){const [a,b]=[...pointers.values()];gesture={panel:m.id,start:state.start,count:state.count,mode:'pinch',distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),center:state.start+fraction((a.x+b.x)/2)*state.count,moved:true};}});
 el.addEventListener('pointermove',e=>{if(!m.geom)return;const p=xy(e);if(!pointers.has(e.pointerId)){if(e.pointerType==='mouse'){state.cursor={panel:m.id,...p};state.hover=Math.max(0,Math.min(state.dates.length-1,Math.round(state.start+fraction(p.x)*state.count-.5)));schedule();}return;}
  pointers.set(e.pointerId,p);if(!gesture||gesture.panel!==m.id)return;
  if(pointers.size===2){e.preventDefault();const [a,b]=[...pointers.values()],dist=Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),count=gesture.count*gesture.distance/dist,anchor=fraction((a.x+b.x)/2);Object.assign(state,N.clamp(gesture.center-count*anchor,count,state.dates.length));gesture.moved=true;sync();return;}
  if(gesture.mode==='pinch')return;const dx=p.x-gesture.x,dy=p.y-gesture.y;if(gesture.mode==='scale'){e.preventDefault();gesture.moved=true;m.yZoom=Math.max(.1,Math.min(10,gesture.yZoom*Math.exp(dy*.008)));schedule();return;}if(!gesture.mode&&Math.max(Math.abs(dx),Math.abs(dy))>7)gesture.mode=e.pointerType==='touch'&&Math.abs(dy)>Math.abs(dx)?'scroll':'pan';
  if(gesture.mode==='pan'){e.preventDefault();gesture.moved=true;state.start=N.clamp(gesture.start-dx/m.geom.width*gesture.count,state.count,state.dates.length).start;state.hover=null;sync();}
 },{passive:false});
 const end=e=>{const p=xy(e);if(gesture&&!gesture.moved&&gesture.mode!=='scroll'){state.cursor={panel:m.id,...p};state.hover=Math.max(0,Math.min(state.dates.length-1,Math.round(state.start+fraction(p.x)*state.count-.5)));schedule();}pointers.delete(e.pointerId);if(el.hasPointerCapture(e.pointerId))el.releasePointerCapture(e.pointerId);if(!pointers.size){gesture=null;endViewAction();}};
 el.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'&&!pointers.size){state.hover=null;schedule();}});
 el.addEventListener('pointerup',end);el.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);gesture=null;if(!pointers.size)endViewAction();});el.addEventListener('lostpointercapture',e=>{pointers.delete(e.pointerId);if(!pointers.size){gesture=null;endViewAction();}});
 el.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','+','=','-','Home','End'].includes(e.key)){e.preventDefault();endViewAction();if(e.key==='+'||e.key==='=')zoomRight(.7);else if(e.key==='-')zoomRight(1.4);else{state.start=e.key==='Home'?0:e.key==='End'?state.dates.length-state.count:state.start+(e.key==='ArrowLeft'?-1:1)*Math.max(1,state.count*.1);sync();}}});
}
$('index').onchange=()=>loadView();$('unit').onchange=()=>{scenarios();loadView();};$('scenario').onchange=()=>loadView();
$('system-1').onclick=()=>setSystem('sys1');$('system-2').onclick=()=>setSystem('sys2');
$('end-year').onchange=()=>endAtYear($('end-year').value);
document.querySelectorAll('[data-years]').forEach(b=>b.onclick=()=>years(b.dataset.years));$('zoom-in').onclick=()=>zoomRight(.7);$('zoom-out').onclick=()=>zoomRight(1.4);$('price-auto').onclick=()=>{endViewAction();for(const m of state.panels)m.yZoom=1;rememberView();schedule();};
$('view-back').onclick=()=>moveViewHistory(-1);$('view-forward').onclick=()=>moveViewHistory(1);
$('apply').onclick=()=>{endViewAction();const from=$('from').value,to=$('to').value,range=N.windowFor(state.dates,from,to);if(!from||!to||from>to||!range){setStatus('Choisis deux dates dans l’historique disponible.');return;}Object.assign(state,range);state.hover=null;setStatus('');sync();};
// Installation help belongs to iPhone Safari, not to the installed app.
// Both iOS's legacy flag and the standard display mode must hide it.
function shouldShowIOSInstallHelp(ua,standalone,displayStandalone){
 return /iPhone|iPod/i.test(ua)&&/Safari/i.test(ua)&&!/(CriOS|FxiOS|EdgiOS|OPiOS)/i.test(ua)&&!standalone&&!displayStandalone;
}
const standaloneDisplay=typeof matchMedia==='function'?matchMedia('(display-mode: standalone)'):null;
function syncIOSInstallHelp(){
 const help=$('ios-install-help');
 if(help)help.hidden=!shouldShowIOSInstallHelp(navigator.userAgent||'',navigator.standalone===true,standaloneDisplay?.matches===true);
}
syncIOSInstallHelp();standaloneDisplay?.addEventListener?.('change',syncIOSInstallHelp);addEventListener('pageshow',syncIOSInstallHelp);
// Move the SAME year selector: keep its selection/listener on resize, and keep
// it reachable when the phone header is folded. Desktop retains its date row.
let mobileYearControl;
function placeYearControl(){
 const phone=compact();
 if(phone!==mobileYearControl){$(phone?'quick-controls':'control-options').append($('year-control'));$(phone?'brand':'quick-controls')[phone?'append':'prepend']($('view-history'));mobileYearControl=phone;}
}
placeYearControl();
$('refresh').onclick=()=>location.reload();addEventListener('resize',()=>{placeYearControl();schedule();});addEventListener('blur',()=>{gesture=null;pointers.clear();endViewAction();});
// Public price charts always use the semi-logarithmic display.
scenarios();
if(compact())$('controls').open=false;
json('catalog.json').then(c=>{if(c.schemaVersion!==1)throw Error('Version de données incompatible');state.catalog=c;return loadView(true);}).catch(e=>setStatus(e.message));
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(()=>{});
})();
